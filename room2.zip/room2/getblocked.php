<?php
session_start();
include ("connection.php");
$uname=$_SESSION['uname'];
$room=$_SESSION['code'];
$ip =$_SESSION['ip'];

$q1="select name from removed WHERE room = '$room'";
$run=mysqli_query($conn,$q1);
$res="";
$i=0;
while($row=mysqli_fetch_assoc($run)){
   $i++;
$res=$res.'<li class="item" onclick="unblock(this);"><i class="uil uil-eye"></i><span>'.$row['name'].'</span></li>';
}
if($res==""){
    echo "-1";
}
echo $res;
?>