<?php
if(isset($_POST['fcode'])){
echo getTelegramFileLink($_POST['fcode']);
}
function getTelegramFileLink($fileId)
{
    $botToken = '6814467734:AAEX_J6KF2Lc--KTsTm88Arb8kw8_kqglb4';
    $apiEndpoint = "https://api.telegram.org/bot{$botToken}/getFile";

    // Build the cURL request
    $postFields = ['file_id' => $fileId];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiEndpoint);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute cURL request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        return ''; // Return empty string on error
    } else {
        // Decode and extract the file path
        $decodedResponse = json_decode($response, true);

        if (isset($decodedResponse['ok']) && $decodedResponse['ok'] === true && isset($decodedResponse['result']['file_path'])) {
            return file_get_contents("https://api.telegram.org/file/bot{$botToken}/{$decodedResponse['result']['file_path']}");
        } else {
            return ''; // Return empty string on invalid response
        }
    }

    // Close cURL session
    curl_close($ch);
}
?>