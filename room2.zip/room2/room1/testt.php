<!-- index.html -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Audio Recorder</title>
    <style>
        #recordButton {
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .recording {
            background-color: #FF7575; /* Change the color as needed */
            transform: scale(1.1);
        }
    </style>
</head>
<body>
    <button id="recordButton">Hold to Record</button>
    <audio id="audioPlayer" controls></audio>

    <script>
        let mediaRecorder;
        let audioChunks = [];
        let isRecording = false;
        let mouseStartY;

        const recordButton = document.getElementById('recordButton');
        const audioPlayer = document.getElementById('audioPlayer');

        recordButton.addEventListener('mousedown', handleMouseDown);
        recordButton.addEventListener('mouseup', handleMouseUp);
        recordButton.addEventListener('mousemove', handleMouseMove);

        async function startRecording() {
            if (!isRecording) {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

                mediaRecorder = new MediaRecorder(stream);

                mediaRecorder.ondataavailable = (event) => {
                    if (event.data.size > 0) {
                        audioChunks.push(event.data);
                    }
                };

                mediaRecorder.onstop = () => {
                    const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
                    const audioUrl = URL.createObjectURL(audioBlob);
                    audioPlayer.src = audioUrl;
                };

                mediaRecorder.start();
                isRecording = true;

                recordButton.textContent = 'Release to Stop';
                recordButton.classList.add('recording');
            }
        }

        function stopRecording() {
            if (isRecording) {
                mediaRecorder.stop();
                isRecording = false;

                recordButton.textContent = 'Hold to Record';
                recordButton.classList.remove('recording');
            }
        }

        function handleMouseDown(event) {
            mouseStartY = event.clientY;
            startRecording();
        }

        function handleMouseUp(event) {
            if (isRecording) {
                stopRecording();
            }
        }

        function handleMouseMove(event) {
            if (isRecording) {
                const currentY = event.clientY;
                const deltaY = currentY - mouseStartY; // Adjusted to check if swiped up

                // Adjust the threshold based on your preference
                if (deltaY < -50) {
                    // User has swiped up, cancel recording
                    stopRecording();
                }
            }
        }
    </script>
</body>
</html>
