<?php
session_start();
include ("connection.php");
$uname=$_SESSION['uname'];
$room=$_SESSION['code'];
$ip =$_SESSION['ip'];
$q ="delete from reg WHERE room_name = '$room' AND owner_name='$uname' AND ip='$ip'";
$run_q=mysqli_query($conn,$q);
unset($_SESSION['code'],$_SESSION['pwd']);
?><script>
    location.replace("index.php")
</script>
<?php
die();
?>