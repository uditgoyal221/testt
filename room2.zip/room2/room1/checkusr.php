<?php
session_start();
include('connection.php');
$c=0;
if (isset($_SESSION['uname']) && isset($_SESSION['code'])) {
    // User is already logged in
    $uname = $_SESSION['uname'];
    $code = $_SESSION['code'];
    $sql="select * from users where room_id='$code'";
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);
    if($num==0){
        echo "Exit";
    }else{
        $time=time();
        while($row=mysqli_fetch_assoc($result)){ 
            if($row['last_login']>$time){
                $c++;
            }}

    echo $c;


// Close the database connection
mysqli_close($conn);
    }
    

} else {
die();
}

?>
