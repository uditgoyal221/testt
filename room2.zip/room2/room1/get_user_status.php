<?php
// error_reporting(0);
session_start();
include("connection.php");
$uname=$_SESSION['uname'];
$code=$_SESSION['code'];
$n=$_POST["usr"];
$time=time();
$sql="select * from users where room_id='$code'";
        $run=mysqli_query($conn,$sql);
        $sql1 = "select * from reg where room_name='$code'";
        $run1 = mysqli_query($conn, $sql1);
        $num = mysqli_num_rows($run1);


        $result_own= mysqli_fetch_assoc($run1);
        $owner=$result_own['owner_name'];
$res="";
while($row=mysqli_fetch_assoc($run)){ 
    if($row['last_login']>$time){
      if($row['username']==$uname){
      $res =$res . '<li class="clearfix"id="li"> ';
      $res =$res . '                                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar">';
      $res =$res . '                                    <div class="about"id="hi1"> ';
      $res =$res . '                                        <div class="name" style="color: green;" id="hi"> You </div>';
      $res =$res . '                                        <div class="status"> <i class="fa fa-circle online"></i> online </div>';
      $res =$res . '                                    </div>';
      $res =$res . '                                </li>';
      }
      else if($row['username']==$owner){
        $res =$res . '<li class="clearfix">';
        $res =$res . '                                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar">';
        $res =$res . '                                    <div class="about">';
        $res =$res . '                                        <div class="name">'.$row['username'].' (OWNER)'.'</div>';
        $res =$res . '                                        <div class="status"> <i class="fa fa-circle online"></i> online </div>';
        $res =$res . '                                    </div>';
        $res =$res . '                                </li>';
  
      }
    else{
      $res =$res . '<li class="clearfix">';
      $res =$res . '                                    <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar">';
      $res =$res . '                                    <div class="about">';
      $res =$res . '                                        <div class="name">'.$row['username'].'</div>';
      $res =$res . '                                        <div class="status"> <i class="fa fa-circle online"></i> online </div>';
      $res =$res . '                                    </div>';
      $res =$res . '                                </li>';

    }}}
    
    echo $res;
  
?>