<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Compression Example</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pako/2.1.0/pako.min.js"></script>
</head>
<body>

<?php
// Function to decode and decompress the data
function decodeAndDecompress($encodedData)
{
    // Ensure $encodedData is a non-empty string before proceeding
    if (!is_string($encodedData) || empty($encodedData)) {
        // Handle the case where $encodedData is not a valid string
        echo "Error: Invalid encoded data.";
        return false;
    }

    // Decode the base64-encoded data
    $compressedData = base64_decode($encodedData);

    if ($compressedData === false) {
        // Handle base64 decoding error
        echo "Error decoding base64 data.";
        return false;
    }

    // Decompress the data
    $decompressedData = gzdecode($compressedData);

    if ($decompressedData === false) {
        // Handle decompression error
        echo "Error decompressing data.";
        return false;
    }

    return $decompressedData;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Receive the compressed base64 string from JavaScript
    $postData = json_decode(file_get_contents('php://input'), true);

    // Log the received data for debugging
    file_put_contents('debug_received_data.txt', print_r($postData, true));

    $compressedBase64 = $postData['compressedBase64'] ?? '';

    // Decode and decompress the base64 string
    $decompressedBase64 = decodeAndDecompress($compressedBase64);

    if ($decompressedBase64 !== false) {
        // Display decompressed base64 code
        echo "<h3>Decompressed Base64 Code</h3>";
        echo "<pre>" . htmlspecialchars($decompressedBase64) . "</pre><br>";

        // Display the image using the decompressed code
        echo "<h3>Decompressed Image</h3>";
        echo "<img src='data:image/png;base64," . base64_encode($decompressedBase64) . "' alt='Decompressed Image' style='max-width: 100%;'><br>";
    } else {
        // Handle errors
        echo "<p>Error processing data. Please check the logs for more information.</p>";
    }
}
?>

<h2>Upload an Image</h2>
<form enctype="multipart/form-data" method="post">
    <input type="file" id="userfile" accept="image/*">
    <button type="button" onclick="uploadAndCompressImage()">Upload and Compress</button>
</form>

<!-- JavaScript to compress and upload the image -->
<script>
function uploadAndCompressImage() {
    var fileInput = document.getElementById('userfile');
    var file = fileInput.files[0];

    if (file) {
        var reader = new FileReader();

        reader.onload = function (e) {
            // e.target.result contains the base64-encoded string
            var base64String = e.target.result;

            // Use pako.js for compression
            var compressedBase64 = pako.gzip(base64String, { to: 'string' });

            // Convert the compressed base64 string to a regular base64 string
            var regularBase64 = btoa(compressedBase64);

            // Log the regular base64 string for debugging
            console.log("Regular Base64 String:", regularBase64);

            // Call a separate function to handle the upload
            handleUpload(regularBase64);
        };

        reader.readAsDataURL(file);
    }
}

// Function to handle the image upload
function handleUpload(regularBase64) {
    // Send the regular base64 string to the server using fetch
    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ compressedBase64: regularBase64 }),
    })
    .then(response => {
        if (response.ok) {
            // Handle the success response (if needed)
            return response.text();
        } else {
            // Handle the error response
            throw new Error('Error:', response.status, response.statusText);
        }
    })
    .then(data => {
        console.log(data);
    })
    .catch(error => {
        // Handle fetch error
        console.error('Fetch error:', error.message);
    });
}
</script>

</body>
</html>
