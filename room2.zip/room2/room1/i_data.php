<?php
session_start();
include("connection.php");
error_reporting(0);
if (isset($_POST['submit']) && isset($_POST['ip'])) {
    $cname = $_POST['cname'];
    $name = $_POST['name'];
    $password = $_POST['password'];
    $c_ip= $_POST['ip'];
    $query = "select * from reg where room_name='$name'";
    $q2 = mysqli_query($conn, "SELECT username FROM `users` WHERE `username` = '$cname' AND `room_id` = '$name';");
    $data = mysqli_query($conn, $query);
    $email_pass = mysqli_fetch_assoc($data);
    $r2 = mysqli_num_rows($q2);
    $db_pass = $email_pass['password'];
    if (password_verify($password, $db_pass)) {
        if ($r2 == 0) {
 
            $_SESSION['code'] = $name;
            $_SESSION['pwd'] = $password;
            $_SESSION['uname'] = $cname;
            $c_ip= $_POST['ip'];
            $_SESSION['ip']=$c_ip;
            header("Location:chat_app.php");

         
        }
        else {

            $q2 = "SELECT * FROM `users` WHERE `username` = '$cname' AND `room_id` = '$name' AND `ip`='$c_ip';";
            $rr=mysqli_query($conn,$q2);
            $rr1 =mysqli_fetch_assoc($rr);
            $s_ip=$rr1['ip'];
            if($c_ip==$s_ip){
            $_SESSION['code'] = $name;
            $_SESSION['pwd'] = $password;
            $_SESSION['uname'] = $cname;
            $c_ip= $_POST['ip'];
            $_SESSION['ip']=$c_ip;
            header("Location:chat_app.php");

            }else{
                ?>
                <script> alert("User Name Already Taken For This Room \n\nTry Different User Name") 
             window.location.href = "index.php";</script>
            <?php
           
            }

            
    } }
    else {
        ?>
        <script>
            alert("Wrong ID or Password")
        </script>
        <?php }}?>