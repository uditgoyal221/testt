<?php
use Ratchet\Server\IoServer;
use React\Socket\Server as ReactServer;
use React\EventLoop\LoopInterface;
use React\EventLoop\Factory as LoopFactory;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;

require __DIR__ . '/vendor/autoload.php';

class VoiceChat implements MessageComponentInterface {
    protected $clients;

    public function __construct() {
        $this->clients = new \SplObjectStorage;
    }

    public function onOpen(ConnectionInterface $conn) {
        $this->clients->attach($conn);
        echo "New connection! ({$conn->resourceId})\n";
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        // Handling text messages (not implemented in this example)
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
        echo "Connection {$conn->resourceId} has disconnected\n";
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        echo "An error occurred: {$e->getMessage()}\n";
        $conn->close();
    }

    public function onVoice(ConnectionInterface $from, $audioBlob) {
        foreach ($this->clients as $client) {
            if ($client !== $from) {
                $client->send($audioBlob);
                echo "Audio sent from {$from->resourceId} to {$client->resourceId}\n";
            }
        }
    }
}

// Create a React Loop
$loop = LoopFactory::create();

// Create a React Server with the Loop
$socketServer = new ReactServer('127.0.0.1:8080', $loop);

// Create an IoServer with the Loop
$server = new IoServer(
    new HttpServer(
        new WsServer(
            new VoiceChat()
        )
    ),
    $socketServer,
    $loop
);

echo "Server is running on http://127.0.0.1:8080\n";

$server->run();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        #voice-chat {
            text-align: center;
            margin-top: 50px;
        }

        audio {
            width: 100%;
            max-width: 400px;
            margin-bottom: 20px;
        }

        button {
            padding: 10px;
            font-size: 16px;
            margin: 0 10px;
        }
    </style>
    <title>Group Voice Chat</title>
</head>
<body>

<div id="voice-chat">
    <audio id="audio" controls></audio>
    <button id="startButton" onclick="startVoiceChat()">Start Voice Chat</button>
    <button id="stopButton" onclick="stopVoiceChat()" disabled>Stop Voice Chat</button>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.1.2/socket.io.js"></script>
<script>
    const socket = io();
    let mediaRecorder;
    let audioChunks = [];

    socket.on('voice', (audioBlob) => {
        const audio = document.getElementById('audio');
        audio.src = URL.createObjectURL(audioBlob);
    });

    function startVoiceChat() {
        navigator.mediaDevices.getUserMedia({ audio: true })
            .then((stream) => {
                mediaRecorder = new MediaRecorder(stream);
                mediaRecorder.ondataavailable = handleAudioData;
                mediaRecorder.onstop = sendVoiceMessage;

                document.getElementById('startButton').disabled = true;
                document.getElementById('stopButton').disabled = false;

                mediaRecorder.start();
            })
            .catch((error) => console.error('Error accessing microphone:', error));
    }

    function stopVoiceChat() {
        mediaRecorder.stop();
        document.getElementById('startButton').disabled = false;
        document.getElementById('stopButton').disabled = true;
    }

    function handleAudioData(event) {
        if (event.data.size > 0) {
            audioChunks.push(event.data);
        }
    }

    function sendVoiceMessage() {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        socket.emit('voice', audioBlob);
        audioChunks = [];
    }
</script>

</body>
</html>
