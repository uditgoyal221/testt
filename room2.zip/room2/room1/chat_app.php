<?php
session_start();
error_reporting(0);
include("connection.php");
if (!isset($_SESSION['code']) && !isset($_SESSION['pwd']) && !isset($_SESSION['uname'])&& !isset( $_SESSION['ip'])) {
  header("Location:index.php");
  die();
} else {
  $code = $_SESSION['code'];
  $uname = $_SESSION['uname'];
  $ip1 = $_SESSION['ip'];
  $sql = "select * from reg where room_name='$code'";
  $run = mysqli_query($conn, $sql);
  $result_own= mysqli_fetch_assoc($run);
  $res = mysqli_num_rows($run);
  if ($res == 1) {
    $owner=$result_own['owner_name'];
    $oip=$result_own['ip'];
    $sql1 = "select * from users where  room_id='$code' and username='$uname'";
    $run1 = mysqli_query($conn, $sql1);
    $res1 = mysqli_num_rows($run1);
    if ($res1 == 0) {
      $query = "INSERT INTO `users` (`ip`,`username`, `room_id`) VALUES ('$ip1','$uname', '$code');";
      $run = mysqli_query($conn, $query);
      $sql = "select * from users where room_id='$code'";
      $run = mysqli_query($conn, $sql);
      $time = time();
    }
    $ow='';
    $re='';
    if($owner==$uname && $oip ==$ip1){
        $ow='<button class="btn" onclick="Destroy()"><i class="fa fa-close"></i> Destroy Room</button>';
        $re='<li class="item"><i class="uil uil-eye"></i><span>Remove</span></li>';
    }else{
        $ow='';
        $re='';
    }
  } else {
    echo "Room ID Not Found";
    header("Location:index.php");
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">


    <title>ChatRoom</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style type="text/css">
        body {
            background-color: #f4f7f6;
            margin-top: 20px;
        }
        input[type="file"] {
            display: none;
        }


        .wrapper {
      visibility: visible;
      opacity: 0;
      transition: opacity 0.3s ease;
      position: absolute;
      width: 300px;
      border-radius: 10px;
      background: #fff;
      box-shadow: 0 12px 35px rgba(0, 0, 0, 0.1);
      z-index: 1000;
    }

    .wrapper.show {
      visibility: visible;
      opacity: 1;
    }

    .wrapper .menu {
      padding: 10px 12px;
    }

    .content .item {
      list-style: none;
      font-size: 22px;
      height: 50px;
      display: flex;
      width: 100%;
      cursor: pointer;
      align-items: center;
      border-radius: 5px;
      margin-bottom: 2px;
      padding: 0 5px 0 10px;
      transition: background 0.3s ease;
    }

    .content .item:hover {
      background: #f2f2f2;
    }

    .content .item span {
      margin-left: 8px;
      font-size: 19px;
    }

    .content .setting {
      display: flex;
      margin-top: -5px;
      padding: 5px 12px;
      border-top: 1px solid #ccc;
    }

    .content .share {
      position: relative;
      justify-content: space-between;
    }

    .share .share-menu {
      position: absolute;
      background: #fff;
      width: 200px;
      right: -200px;
      top: -35px;
      padding: 13px;
      opacity: 0;
      pointer-events: none;
      border-radius: 10px;
      box-shadow: 0 5px 10px rgba(0, 0, 0, 0.08);
      transition: 0.2s ease;
    }

    .share:hover .share-menu {
      opacity: 1;
      pointer-events: auto;
    }

    .apples-list {
      margin-top: 20px;
      padding: 10px 12px;
      background: #f2f2f2;
      border-radius: 10px;
    }

    .apples-list h3 {
      font-size: 18px;
      margin-bottom: 8px;
    }

    .apples-list ul {
      list-style: none;
      padding: 0;
    }

    .apples-list li {
      font-size: 16px;
      margin-bottom: 5px;
    }



        
        /* Style for the custom button */
        #fileButton {
            padding: 10px;
            font-size: x-large;
            padding:0px,0px;
            color: #fff;
            cursor: pointer;
            border: none;
        }
        .card {
            background: #fff;
            transition: .5s;
            border: 0;
            margin-bottom: 30px;
            border-radius: .55rem;
            position: relative;
            width: 100%;
            box-shadow: 0 1px 2px 0 rgb(0 0 0 / 10%);
        }

        .chat-app .people-list {
            width: 280px;
            position: absolute;
            left: 0;
            top: 0;
            padding: 20px;
            z-index: 7
        }

        .chat-app .chat {
            margin-left: 280px;
            border-left: 1px solid #eaeaea
        }

        .people-list {
            -moz-transition: .5s;
            -o-transition: .5s;
            -webkit-transition: .5s;
            transition: .5s
        }

        .people-list .chat-list li {
            padding: 10px 15px;
            list-style: none;
            border-radius: 3px
        }

        .people-list .chat-list li:hover {
            background: #efefef;
            cursor: pointer
        }

        .people-list .chat-list li.active {
            background: #efefef
        }

        .people-list .chat-list li .name {
            font-size: 15px
        }

        .people-list .chat-list img {
            width: 45px;
            border-radius: 50%
        }

        .people-list img {
            float: left;
            border-radius: 50%
        }

        .people-list .about {
            float: left;
            padding-left: 8px
        }

        .people-list .status {
            color: #999;
            font-size: 13px
        }

        .chat .chat-history {
            height: 500px;
            padding: 20px;
            border-bottom: 2px solid #fff;
            max-height: 500px;
            overflow-y: scroll;

        }

        .chat .chat-header img {
            float: left;
            border-radius: 40px;
            width: 40px
        }

        .chat .chat-header .chat-about {
            float: left;
            padding-left: 10px
        }

        .chat .chat-history {
            padding: 20px;
            border-bottom: 2px solid #fff
        }

        .chat .chat-history ul {
            padding: 0
        }
        #fileButton {
    color: white;
    padding: 0px 1px;
    font-weight: bold;
    border-radius: 4px;
    width:auto;
}
        .chat .chat-history ul li {
            list-style: none;
            margin-bottom: 30px
        }

        .chat .chat-history ul li:last-child {
            margin-bottom: 0px
        }

        .chat .chat-history .message-data {
            margin-bottom: 15px
        }

        .chat .chat-history .message-data img {
            border-radius: 40px;
            width: 40px
        }

        .chat .chat-history .message-data-time {
            color: #434651;
            padding-left: 6px
        }

        .chat .chat-history .message {
            color: #444;
            padding: 18px 20px;
            line-height: 26px;
            font-size: 16px;
            border-radius: 7px;
            display: inline-block;
            position: relative
        }

        .chat .chat-history .message:after {
            bottom: 100%;
            left: 7%;
            border: solid transparent;
            content: " ";
            height: 0;
            width: 0;
            position: absolute;
            pointer-events: none;
            border-bottom-color: #fff;
            border-width: 10px;
            margin-left: -10px
        }

        .chat .chat-history .my-message {
            background: #efefef
        }

        .chat .chat-history .my-message:after {
            bottom: 100%;
            left: 30px;
            border: solid transparent;
            content: " ";
            height: 0;
            width: 0;
            position: absolute;
            pointer-events: none;
            border-bottom-color: #efefef;
            border-width: 10px;
            margin-left: -10px
        }

        .chat .chat-history .other-message {
            background: #e8f1f3;
            text-align: right
        }

        .chat .chat-history .other-message:after {
            border-bottom-color: #e8f1f3;
            left: 93%
        }

        .chat .chat-message {
            padding: 20px
        }

        .online,
        .offline,
        .me {
            margin-right: 2px;
            font-size: 8px;
            vertical-align: middle
        }

        .online {
            color: #86c541
        }

        .offline {
            color: #e47297
        }

        .me {
            color: #1d8ecd
        }

        .float-right {
            float: right
        }

        .clearfix:after {
            visibility: hidden;
            display: block;
            font-size: 0;
            content: " ";
            clear: both;
            height: 0
        }

        @media only screen and (max-width: 767px) {
            .chat-app .people-list {
                height: 127px;
                width: 100%;
                overflow-x: auto;
                background: #fff;
                left: -2px;
                display: block;
                margin-top: 587px;
            }

            .chat-app .people-list.open {
                left: 0
            }

            .chat-app .chat {
                margin: 0
            }

            .chat-app .chat .chat-header {
                border-radius: 0.55rem 0.55rem 0 0
            }

            .chat-app .chat-history {
                height: 300px;
                overflow-x: auto
            }
        }

        @media only screen and (min-width: 768px) and (max-width: 992px) {
            .chat-app .chat-list {
                height: 650px;
                overflow-x: auto
            }

            .chat-app .chat-history {
                height: 600px;
                overflow-x: auto
            }
        }

        @media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (orientation: landscape) and (-webkit-min-device-pixel-ratio: 1) {
            .chat-app .chat-list {
                height: 480px;
                overflow-x: auto
            }

            .chat-app .chat-history {
                height: calc(100vh - 350px);
                overflow-x: auto
            }
        }

        .overflow {
            overflow-y: scroll;
            max-height: 500px;
            /* Adjust the max-height value as needed */
        }

        .btn {
            margin-top: 2px;
            margin-right: 10px;
            background-color: rgb(255, 30, 30);
            border: none;
            color: white;
            padding: 12px 16px;
            font-size: 14px;
            cursor: pointer;
            border-radius: 10px;
        }


        .btn:hover {
            background-color: rgb(235, 68, 68);
        }
        #usermsg {
        /* Styles for the text input */
        width: 45vw;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
    }
    
    #submitmsg {
        /* Styles for the submit button */
        padding: 10px 20px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        font-size: 16px;
        cursor: pointer;
    }
    #submitmsg,
    #enter {

      color: white;
      padding: 4px 10px;
      font-weight: bold;
      border-radius: 4px;
    }
    
    </style>
</head>

<body>
<div class="wrapper">
    <div class="content">
      <ul class="menu">
        
        <?php echo $re?>
        <li class="item">
          <i class="uil uil-link-alt"></i>
          <span>Get Link</span>
        </li>
        <li class="item">
          <i class="uil uil-edit"></i>
          <span>Rename</span>
        </li>
        <li class="item">
          <i class="uil uil-trash-alt"></i>
          <span>Delete</span>
        </li>
      </ul>
      <div class="setting">
        <li class="item">
          <i class="uil uil-setting"></i>
          <span>Settings</span>
        </li>
      </div>
      
    </div>
  </div>
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <div class="container">
      
        <div class="row clearfix">
            <div class="col-lg-12">
                <div class="card chat-app">
                    <div id="plist" class="people-list">

                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fa fa-search"></i></span>
                            </div>
                            <form>
                            <input type="text" class="form-control" placeholder="Search...">
                            </form>
                        </div>

                        <div class="overflow">
                          
                            <ul  class="list-unstyled chat-list mt-2 mb-0">
                              
                                <div class= 'userstatus' id="div1">

                                    <!-- USER STATUS -->
                                </div>

  
                            </ul>
                        </div>
                    </div>
                    <div class="chat">
                        <div class="chat-header clearfix">
                            <hr>
                            <div class="row">
                                <div class="col-lg-6">
                                    <a href="javascript:void(0);" data-toggle="modal" data-target="#view_info">
                                        <img src="https://bootdey.com/img/Content/avatar/avatar2.png" alt="avatar">
                                    </a>
                                    <div class="chat-about">
                                        <h6 class="m-b-0">Room Name -  <?php echo $_SESSION['code']; ?> </h6>
                                        <small>Owner Name - <?php echo $owner; ?></small>
                                    </div>
                                </div>
                                <div class="col-lg-6 hidden-sm text-right">
                                    <button class="btn" onclick="logout()"><i class="fa fa-close"></i> Exit</button>
                                    <?php echo $ow; ?>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="chat-history">
                            <ul class="m-b-0">
                                <div class='anyclass'>
                                <!-- MSG -->
                                
                        </li><br>
                                </div>
                            </ul>
                        </div>
                        <div class="chat-message clearfix">
                            <div class="input-group mb-0">
                                <form method="POST" id="msg">
                                    <div class="input-group-prepend">
                                    <input name="usermsg" id="usermsg" type="text" class="form-control"
                                    placeholder="Enter text here..." required onkeypress="handleKeyPress(event)">
                                    <input type="file" name="file" id="fileInput"onchange="updateFileName()" accept="image/*, video/*, application/pdf">
                                    <button type="button"   id="fileButton" onclick="chooseFile()">📁</button>
                                    

                               <input type="submit" value="Submit" name="submitmsg" id="submitmsg">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js" integrity="sha256-o88AwQnZB+VDvE9tvIXrMQaPlFFSUTR+nldQm1LuPXQ=" crossorigin="anonymous"></script>
    <script>

var msg=0;
var users=0;
        function hasClass(element, className) {
    return element.classList.contains(className);
}
            function downloadFile(element){
                console.log(element.id);

                    if(hasClass(element,"img0")){
                        element.src="/room1/loading.gif";
                $.ajax({
                        url: 'getImg.php',
                        type: 'POST',
                        data: {
                            fcode:element.id,
                        },
                        success: function (response) {
                            element.outerHTML = '<img class="img0" id="'+element.id+'" src="' + response + '" alt="Image" width="280px" height="250">'
                           element.src = response;
                        },
                        error: function (xhr, status, error) {
                            // Handle errors
                        }
                    });
                }else if(hasClass(element,"pdf")){
                    element.src="/room1/loading.gif";
                    $.ajax({
                        url: 'getImg.php',
                        type: 'POST',
                        data: {
                            fcode:element.id,
                        },
                        success: function (response) {
                           
                            element.outerHTML = '<iframe id="' + element.id + '" src="' + response + '" width="280px" height="600px"></iframe>';

                           element.src = response;
                        },
                        error: function (xhr, status, error) {
                            // Handle errors
                        }
                    });
                }else if(hasClass(element,"vid")){
                    element.src="/room1/loading.gif";
                    $.ajax({
                        url: 'getImg.php',
                        type: 'POST',
                        data: {
                            fcode:element.id,
                        },
                        success: function (response) {
                           
                            element.outerHTML = '<video  width="384" height="216" controls ><source src="'+response+'" type="video/mp4"></video>';

                           element.src = response;
                        },
                        error: function (xhr, status, error) {
                            // Handle errors
                        }
                    });

                }

            }

            function ran(length) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let result = '';

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * characters.length);
    result += characters.charAt(randomIndex);
  }

  return result;
}
         function updateFileName() {
            var rand=ran(15);
            var typ;
    let fileInput = document.getElementById('fileInput');

    if (fileInput.files.length > 0) {
        var inputElement = document.getElementById('fileInput');

        // Check if any file is selected
        if (inputElement.files.length > 0) {
            // Get the selected file
            var file = inputElement.files[0];
            
        if (file) {
            var fileType =file.type;
            data='';
            data2='<li class="clearfix"><div class="message-data text-right"><span class="message-data-time"><?php echo $_SESSION['uname'].' '.date("H:i:s", time()); ?></span><img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar"></div><div class="message other-message float-right"><img class="img0" id="'+rand+'" src="/room1/upload.gif" alt="Image" width="280px" height="250" "></div></li><br>';
               

            if (fileType.startsWith('image/')) {
               typ="img";
               
               data='<li class="clearfix"><div class="message-data text-right"><span class="message-data-time"><?php echo $_SESSION['uname'].' '.date("H:i:s", time()); ?></span><img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar"></div><div class="message other-message float-right"><img class="img0" id="'+rand+'" src="'+ URL.createObjectURL(file) +'" alt="Image" width="280px" height="250" "></div></li><br>';
               
            } else if (fileType.startsWith('video/')) {
                typ="vid";
                data='<li class="clearfix"><div class="message-data text-right"><span class="message-data-time"><?php echo $_SESSION['uname'].' '.date("H:i:s", time()); ?></span><img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar"></div><div class="message other-message float-right"><video id="'+rand+'" width="384" height="216" controls autoplay><source src="'+ URL.createObjectURL(file) +'" type="video/mp4"></video></div></li><br>';
            } else if (fileType === 'application/pdf') {
                typ="pdf";
                data='<li class="clearfix"><div class="message-data text-right"><span class="message-data-time"><?php echo $_SESSION['uname'].' '.date("H:i:s", time()); ?></span><img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar"></div><div class="message other-message float-right"><iframe id="'+rand+'"  src="' + URL.createObjectURL(file) +  '" width="280px" height="600px"></iframe></video></div></li><br>';
            } else {
                return;
            }
            
            newData=document.getElementsByClassName('anyclass')[0].innerHTML+data2;
            
            document.getElementsByClassName('anyclass')[0].innerHTML = newData;
        }
    
            // Create a FileReader
            var reader = new FileReader();

            // Set the onload event handler
            reader.onload = function (e) {
                // e.target.result contains the base64-encoded string
                var base64String = e.target.result;

                // Get the user's IP address
                $.getJSON("https://api.ipify.org?format=json", function (data) {
                    var ipp = data.ip;

                    $.ajax({
                        url: 'chat_data.php',
                        type: 'POST',
                        data: {
                            bcode: base64String,
                            type:typ,
                            ip: ipp,
                            code: '<?php echo $_SESSION['code'] ?>',
                            uname: '<?php echo $_SESSION['uname'] ?>'
                        },
                        success: function (response) {
                           msg++;
                           src= URL.createObjectURL(file);
                           element = document.getElementById(rand);
                           console.log(typ);
                           if(typ=="img"){
                           element.outerHTML = '<img class="img0" id="'+element.id+'" src="' +src+ '" alt="Image" width="280px" height="250">';
                        }else if(typ=="vid"){
                            element.outerHTML = '<video id="'+element.id+'"  width="384" height="216" controls ><source src="'+src+'" type="video/mp4"></video>';

                        }else if(typ=="pdf"){
                            element.outerHTML = '<iframe id="' + element.id + '" src="' + src + '" width="280px" height="600px"></iframe>';
                        }

                        },
                        error: function (xhr, status, error) {
                            // Handle errors
                        }
                    });

                    // Reset the form after the Ajax request
                    var form = document.getElementById("msg");
                    form.reset();
                });
            };

            // Read the file as a data URL, which will result in a base64-encoded string
            reader.readAsDataURL(file);
        } else {

        }
    } else {
       
    }
}

            function chooseFile() {
        document.getElementById('fileInput').click();
    }
         
        function logout(){
            var userres=window.confirm("Are you sure you want to exit?");
            if(userres){
                location.replace('logout.php');
            }
            
        }
        function forceLogout(){

                location.replace('logout.php');
            
        }
        function Destroy(){
            var userres=window.confirm("Are you sure to destroy room?");
            if(userres){
                location.replace('Destroy.php');
            }
        }
      function updateUserStatus() {
        jQuery.ajax({
          url: 'update_user_status.php',
          success: function() {
  
          },
        });
      }
  
      setInterval(function() {
          updateUserStatus();
        }, 1000
  
      )
 
       setInterval(checkNewMsg, 1000);
    function checkNewMsg() {
        $.post("checkmsg.php", {
            msg:msg,
            room: '<?php echo $code ?>'
          },
          function(data, status) {
           if(data=="Exit"){
            window.alert("The room is Closed !!");
            forceLogout();
           }
            else if(msg<data){
                runFunction();
                msg=data;
            }
          },
          
        )
        }
      
      function runFunction() {
        $.post("htcont2.php", {
            room: '<?php echo $code ?>',
            check:msg
          },
          function(data, status) {
            newData=document.getElementsByClassName('anyclass')[0].innerHTML+data;
            
            document.getElementsByClassName('anyclass')[0].innerHTML = newData;
          },
          
        )
  
      }
      
      setInterval(checkusr, 1000);
      function checkusr() {
        $.post("checkusr.php", {
            room: '<?php echo $code ?>'
          },
          function(data, status) {
           if(data=="Exit"){
            window.alert("The room is Closed !!");
            forceLogout();
           }
            else if(users!=data){
                console.log (users+" "+data);
                getFunction();
                users=data;
            }
          },
          
        )
        }
      function getFunction() {
        $.post("get_user_status.php", {
            room: '<?php echo $code ?>',
            uname: '<?php echo $uname ?>',
            usr: users
          },
          function(data, status) {

          document.getElementsByClassName('userstatus')[0].innerHTML = data;
        
        }
        )
      }
      
      $(document).ready(function() {
    $('#msg').submit(function(event) {
        event.preventDefault();
        var clientmsg = 1;
        var ipp;


        $.getJSON("https://api.ipify.org?format=json", function(data) {
            ipp = data.ip;

            $.ajax({
                url: 'chat_data.php',
                type: 'POST',
                data: $('#msg').serialize() + '&ip=' + ipp,
                room: '<?php echo $_SESSION['code'] ?>',
                uname: '<?php echo $_SESSION['uname'] ?>',

            });

            // Reset the form after the Ajax request
            var form = document.getElementById("msg");
            form.reset();
        });

        return false;
    });
});

      function handleKeyPress(event) {
        if (event.shiftKey && event.keyCode === 13) {
          event.preventDefault();
  
          var input = document.getElementById('usermsg');
          var startPos = input.selectionStart;
          var endPos = input.selectionEnd;
  
          // Insert a line break or space at the current cursor position
          var newValue = input.value.substring(0, startPos) + ' ' + input.value.substring(endPos);
          input.value = newValue;
  
          // Move the cursor position to the appropriate location
          input.selectionStart = input.selectionEnd = startPos + 1;
        }
      }
      
      const contextMenu = document.querySelector(".wrapper");


let rightClickedUserStatus = ''; 

// Function to handle context menu display
const showContextMenu = (x, y) => {
  let winWidth = window.innerWidth,
    winHeight = window.innerHeight,
    cmWidth = contextMenu.offsetWidth,
    cmHeight = contextMenu.offsetHeight;

 

  x = x > winWidth - cmWidth ? winWidth - cmWidth - 5 : x;
  y = y > winHeight - cmHeight ? winHeight - cmHeight - 5 : y;
  // x = x - 200;
  contextMenu.style.left = `${x}px`;
  contextMenu.style.top = `${y}px`;
  contextMenu.classList.add("show");
};

// Right-click event listener on the user status elements
const userStatusElements = document.querySelectorAll('.userstatus');
userStatusElements.forEach(element => {
  element.addEventListener("contextmenu", e => {
    e.preventDefault();

    // Update the variable with the content of the clicked user status
    rightClickedUserStatus = element.textContent;
    console.log("Right-clicked user status:", rightClickedUserStatus);
    // Show the context menu
    showContextMenu(e.clientX, e.clientY);
  });

  // Long-press event listener for mobile devices
  let touchStartTime;
  element.addEventListener("touchstart", e => {
    touchStartTime = new Date().getTime();
  });

  element.addEventListener("touchend", e => {
    const touchEndTime = new Date().getTime();
    const touchDuration = touchEndTime - touchStartTime;

    // Check if it's a long press (more than 500ms)
    if (touchDuration ) {
      e.preventDefault();
      // Update the variable with the content of the clicked user status
      rightClickedUserStatus = element.id;

      // Show the context menu
      showContextMenu(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
    }
  });
});

document.addEventListener("click", () => {
  // Access the rightClickedUserStatus variable when needed
 

  // Move the context menu out of the screen on a normal click
  contextMenu.style.left = "-9999px";
  contextMenu.style.top = "-9999px";

  contextMenu.classList.remove("show");
});


    </script>

</body>

</html>