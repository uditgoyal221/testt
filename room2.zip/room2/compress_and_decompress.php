<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Compression Example</title>
</head>
<body>

<?php
function f(){
  return "hi";
}
// Function to compress and encode the data
function compressAndEncode($data)
{
    $compressedData = gzencode($data, 9);
    $encodedData = base64_encode($compressedData);

    return $encodedData;
}

// Function to decode and decompress the data
function decodeAndDecompress($encodedData)
{
    // Decode the base64-encoded data
    $compressedData = base64_decode($encodedData);
    // Decompress the data
    $decompressedData = gzdecode($compressedData);

    return $decompressedData;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_FILES['userfile']['error'] === UPLOAD_ERR_OK) {
        $fileType = $_FILES['userfile']['type'];
        $fileName = $_FILES['userfile']['name'];
        $fileContent = file_get_contents($_FILES['userfile']['tmp_name']);

        // Convert the image content to base64
        $base64String = base64_encode($fileContent);

        // Compress and encode the base64 string
        $compressedBase64 = compressAndEncode($base64String);

        // Display compressed base64 code
        echo "<h3>Compressed Base64 Code</h3>";
        echo "<pre>" . htmlspecialchars($compressedBase64) . "</pre><br>";

        // Decode and decompress the base64 string
        $decompressedBase64 = decodeAndDecompress($compressedBase64);

        // Display decompressed base64 code
        echo "<h3>Decompressed Base64 Code</h3>";
        echo "<pre>" . htmlspecialchars($decompressedBase64) . "</pre><br>";

        // Display the image using the decompressed code
        echo "<h3>Decompressed Image</h3>";
        echo "<img src='data:$fileType;base64," .$decompressedBase64 . "' alt='Decompressed Image' style='max-width: 100%;'><br>";
    } else {
        echo "Error uploading image.";
    }
}
?>

<!-- Image upload form -->
<h2>Upload an Image</h2>
<form enctype="multipart/form-data" method="post">
    <input type="file" name="userfile" accept="image/*">
    <input type="submit" value="Upload Image">
    <?php echo f(); ?>
</form>
<script>
  var b='<?php echo f()?>';
  function f(){
    console.log(b);
  }
  f();
  </script>
</body>
</html>
