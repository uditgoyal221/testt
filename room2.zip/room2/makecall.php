<?php
session_start();
include ("connection.php");
$user=$_POST['username'];
$uname=$_SESSION['uname'];
$room=$_SESSION['code'];
$ip =$_SESSION['ip'];
$callid=$_POST["vcode"].','.$uname;
$q1 = "UPDATE users SET call_id='$callid' WHERE username ='$user' and room_id='$room'";

    $run_2=mysqli_query($conn,$q1);
?>