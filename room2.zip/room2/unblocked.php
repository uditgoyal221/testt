<?php
session_start();
include ("connection.php");
$uname=$_SESSION['uname'];
$user=$_POST['user'];
$room=$_SESSION['code'];
$ip =$_SESSION['ip'];
$q1=mysqli_query($conn,"select * from reg WHERE room_name = '$room' AND owner_name='$uname' AND ip='$ip'");
$res=mysqli_num_rows($q1);
if($res>0){
    $q1="DELETE FROM `removed` WHERE room='$room' and name='$user'";
    $run=mysqli_query($conn,$q1);
    $q1="UPDATE users SET removed='not' WHERE username ='$user'";
    $run=mysqli_query($conn,$q1);
}





?>