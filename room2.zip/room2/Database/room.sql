-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2024 at 09:17 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `room`
--

-- --------------------------------------------------------

--
-- Table structure for table `msg`
--

CREATE TABLE `msg` (
  `ip` varchar(255) NOT NULL,
  `msg` varchar(50) NOT NULL,
  `stime` time NOT NULL DEFAULT current_timestamp(),
  `uname` varchar(50) NOT NULL,
  `room` varchar(50) NOT NULL,
  `fcode` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msg`
--

INSERT INTO `msg` (`ip`, `msg`, `stime`, `uname`, `room`, `fcode`) VALUES
('103.172.73.184', 'chat1231❄udit❄img❄66660', '18:21:44', 'udit', 'chat1231', 'BQACAgUAAxkDAAMFZaPZFRR6Jzz3vR9OzePiliPbVrgAAvEOAAK5KSBV00vvUpPDoBU0BA'),
('103.172.73.184', 'chat1231❄udit❄pdf❄82275', '18:30:50', 'udit', 'chat1231', 'BQACAgUAAxkDAAMGZaPbN4aOfX41yFpshpKIlLvxRnQAAvMOAAK5KSBVbnXVAAF2-0NDNAQ'),
('103.172.73.184', 'chat1231❄udit❄img❄23741', '18:32:58', 'udit', 'chat1231', 'BQACAgUAAxkDAAMHZaPbtzDmTDu_YR-IxY7yqiVz8UsAAvQOAAK5KSBVr0LJjQr81qo0BA'),
('103.172.73.184', 'chat1231❄udit❄img❄32838', '18:33:27', 'udit', 'chat1231', 'BQACAgUAAxkDAAMIZaPb04C1n1lO88PLIpmplPrlWOwAAvUOAAK5KSBVksrA6vzj6JU0BA'),
('103.172.73.184', 'hi', '18:41:04', 'udit', 'chat1231', NULL),
('103.172.73.184', 'sags', '18:41:09', 'udit', 'chat1231', NULL),
('103.172.73.184', '5y', '18:41:13', 'udit', 'chat1231', NULL),
('103.172.73.184', 'chat1231❄udit❄img❄82877', '18:41:26', 'udit', 'chat1231', 'BQACAgUAAxkDAAMJZaPdsj_-zpriaoSYk9DeVHVNlwoAAvcOAAK5KSBVePrhCx9Hkwg0BA'),
('103.172.73.184', 'hi i am ayush', '18:43:14', 'ayush', 'chat1231', NULL),
('103.172.73.184', 'chat1231❄cvbd❄img❄91168', '18:48:09', 'cvbd', 'chat1231', 'BQACAgUAAxkDAAMKZaPfRm9y4-opwpgQ7rk3zBhbY3UAAv8OAAK5KSBVD1eDejB1L300BA'),
('103.172.73.184', 'chat1231❄cvbd❄img❄69273', '18:48:29', 'cvbd', 'chat1231', 'BQACAgUAAxkDAAMLZaPfWZrTg-EIcs9VLYF5na8R_FoAAw8AArkpIFXeEgYAAXHQ2tc0BA'),
('103.172.73.184', 'chat1231❄cvbd❄img❄75080', '18:48:55', 'cvbd', 'chat1231', 'BQACAgUAAxkDAAMMZaPfcxPS3d7WDl7Sjy29JwAB9v54AAICDwACuSkgVZn392uqJSwINAQ'),
('103.172.73.184', 'chat1231❄cvbd❄img❄35295', '18:49:00', 'cvbd', 'chat1231', 'BQACAgUAAxkDAAMNZaPfebFUat3pITUKAcqvUdoeDiYAAgMPAAK5KSBVpOaBRUjHHuU0BA'),
('103.172.73.184', 'chat1231❄ayush❄img❄20561', '18:49:23', 'ayush', 'chat1231', 'BQACAgUAAxkDAAMOZaPfkOfWnT5VPcNPWp7cm9qgYB8AAgUPAAK5KSBVbp0UGInHjTw0BA'),
('103.172.73.184', 'chat1231❄cvbd❄img❄30998', '18:56:33', 'cvbd', 'chat1231', 'BQACAgUAAxkDAAMPZaPhPhDYyupNh0SrWYrBLpIlqmUAAgwPAAK5KSBVP15v9rZ-NFo0BA'),
('103.172.73.184', 'Hey', '18:57:34', 'ayush', 'chat1231', NULL),
('103.172.73.184', 'chat1231❄ayush❄img❄39221', '18:57:41', 'ayush', 'chat1231', 'BQACAgUAAxkDAAMQZaPhgV2xp2gjVlGYAAEpPrmhBBvEAAINDwACuSkgVYcQF1isrxQrNAQ'),
('103.172.73.184', 'chat1231❄cvbd❄img❄17319', '18:58:10', 'cvbd', 'chat1231', 'BQACAgUAAxkDAAMRZaPhnocjCecoUTwzTbItGqCT0kEAAg8PAAK5KSBVGcPR86Nbbhg0BA'),
('103.172.73.184', 'fgft', '18:58:31', 'cvbd', 'chat1231', NULL),
('103.172.73.184', 'hi', '19:45:56', 'cvbd', 'chat1231', NULL),
('103.172.73.184', 'chatjg❄udit❄img❄92276', '20:11:08', 'udit', 'chatjg', 'BQACAgUAAxkDAAMdZaPyuKGXs-bx8a5ndglcNz8dv6cAAjYPAAK5KSBVBwlpRzMMOns0BA'),
('103.172.73.184', 'chatjg❄udit❄img❄97194', '20:11:41', 'udit', 'chatjg', 'BQACAgUAAxkDAAMeZaPy2df_xwdkBQc4mkywhkJ8JXIAAjcPAAK5KSBVakdibZVcXAc0BA'),
('103.172.73.184', 'chatjg❄udit❄img❄30632', '20:12:03', 'udit', 'chatjg', 'BQACAgUAAxkDAAMfZaPy75RHxVBAxPACGC0wHJTqkY0AAjgPAAK5KSBV-1X0IuF0Fgs0BA'),
('103.172.73.184', 'chatjg❄udit❄img❄37332', '20:13:00', 'udit', 'chatjg', 'BQACAgUAAxkDAAMgZaPzKD2zYNr3eu1zGPDW2f2cTnMAAjkPAAK5KSBV1hKLijwjjDk0BA'),
('103.172.73.184', 'chatjg❄udit❄img❄69225', '20:34:06', 'udit', 'chatjg', 'BQACAgUAAxkDAAMhZaP4GmggSi4ryfCaHB4VJCnWEIQAAj0PAAK5KSBVGtKHdjclYNI0BA'),
('103.172.73.184', 'chatjg❄udit❄pdf❄99875', '20:38:43', 'udit', 'chatjg', 'BQACAgUAAxkDAAMiZaP5L049r6qlG7HIFdM8TvxMKdQAAj4PAAK5KSBV0vNL2xq1qLI0BA'),
('103.172.73.184', 'chatjg❄udit❄pdf❄52420', '20:39:06', 'udit', 'chatjg', 'BQACAgUAAxkDAAMjZaP5RmdoM5h9LC6pcyV3IgrlG5MAAj8PAAK5KSBV6a-G9SxG9mE0BA'),
('103.172.73.184', 'chat1231❄ayush❄pdf❄20049', '20:59:03', 'ayush', 'chat1231', 'BQACAgUAAxkDAAMkZaP99GNCENQGO0QgHtk7ZMLi9v8AAkEPAAK5KSBVJODLHKVre1s0BA'),
('103.172.73.184', 'chatjg❄udit❄pdf❄79483', '21:01:18', 'udit', 'chatjg', 'BQACAgUAAxkDAAMlZaP-efzBweuDmSfleUVNuIxPQLsAAkQPAAK5KSBVf77A1o0kf0M0BA'),
('103.172.73.184', 'chatjg❄udit❄pdf❄43568', '21:01:23', 'udit', 'chatjg', 'BQACAgUAAxkDAAMmZaP-f5hsYYOxlWP5QgWQe15y9icAAkUPAAK5KSBVE6UBRG9q2H40BA'),
('103.172.73.184', 'chatjg❄udit❄pdf❄32918', '21:03:07', 'udit', 'chatjg', 'BQACAgUAAxkDAAMnZaP-5wM4E2OpDs1Y6JRO0bdHMMIAAkkPAAK5KSBV6wbjcEuXF-I0BA'),
('103.172.73.184', 'chatjg❄udit❄pdf❄80916', '21:04:07', 'udit', 'chatjg', 'BQACAgUAAxkDAAMoZaP_IwABN7KrOU3SfARMgXO_cC56AAJLDwACuSkgVdVjy6qs2jlLNAQ'),
('103.172.73.184', 'chatjg❄udit❄img❄59353', '21:06:59', 'udit', 'chatjg', 'BQACAgUAAxkDAAMpZaP_z4QcZs2Mos49jKt215MibY8AAk0PAAK5KSBVOnipGQSn_p40BA'),
('103.172.73.184', 'chatjg❄udit❄vid❄41796', '21:12:34', 'udit', 'chatjg', 'BQACAgUAAxkDAAMqZaQBHlLLv7tqq33x8IVfhD96wdYAAk8PAAK5KSBVS4tYv0oa6Tw0BA'),
('103.172.73.23', 'fuff❄udit❄vid❄40970', '15:47:12', 'udit', 'fuff', 'BQACAgUAAxkDAAM4ZazvZEE6ytVPnhGboF4UvufhZy0AAuQQAALuw2hVql_NOoCZ1pA0BA'),
('103.172.73.23', 'fuff❄udit❄img❄67124', '15:59:23', 'udit', 'fuff', 'BQACAgUAAxkDAAM5ZazyP9YGdxPt0bZCwD6AfC2HhSgAAgERAALuw2hVGHROazgeRD00BA'),
('103.172.73.23', 'fuff❄udit❄img❄63111', '16:03:46', 'udit', 'fuff', 'BQACAgUAAxkDAAM6ZazzRv_PAAGHFlR0004JI3SCfUOiAAICEQAC7sNoVZO8VhCt8_3VNAQ'),
('103.172.73.23', 'fuff❄ayush❄img❄34339', '16:05:00', 'ayush', 'fuff', 'BQACAgUAAxkDAAM7ZazzkWH1Of8C0FKbsQMuedTjHsAAAgMRAALuw2hVWFfc4KRYh-I0BA'),
('103.172.73.23', 'fuff❄ayush❄img❄34573', '16:12:17', 'ayush', 'fuff', 'BQACAgUAAxkDAAM8Zaz1RfMHbyWLZfLq1Ivys3Itl2kAAgURAALuw2hVt4e7b3LgzQc0BA'),
('103.172.73.23', 'fuff❄udit❄img❄18966', '16:13:09', 'udit', 'fuff', 'BQACAgUAAxkDAAM9Zaz1eXi4wshpkfgY4uIpHHK-qMkAAgYRAALuw2hVLYOJZNuQqzM0BA'),
('103.172.73.23', 'fuff❄udit❄img❄78169', '16:14:52', 'udit', 'fuff', 'BQACAgUAAxkDAAM-Zaz14O1qtrPBHhZu2ZScvw3mn4MAAggRAALuw2hViwH8lIcHwqI0BA'),
('103.172.73.23', 'fuff❄udit❄img❄87886', '16:22:33', 'udit', 'fuff', 'BQACAgUAAxkDAAM_Zaz3reajnqXLCJUhgPvRj-lop_4AAgoRAALuw2hVtcjDD-l4d0g0BA'),
('103.172.73.23', 'fuff❄udit❄img❄58063', '16:22:41', 'udit', 'fuff', 'BQACAgUAAxkDAANAZaz3tX3DIGMgKnSZZZgleaPuesgAAgwRAALuw2hVSuUhgFUKU3Q0BA'),
('103.172.73.23', 'fuff❄ayush❄img❄89892', '16:23:01', 'ayush', 'fuff', 'BQACAgUAAxkDAANBZaz3yTDNg4YC9o8Zb09d5RG7gpEAAg4RAALuw2hVE4WSRX0sdjs0BA'),
('103.172.73.23', 'fuff❄ayush❄img❄94213', '16:25:45', 'ayush', 'fuff', 'BQACAgUAAxkDAANCZaz4btbmgbkNiwoNxbBqwzWpInIAAhURAALuw2hVpZKGDAABv6IeNAQ'),
('103.172.73.23', 'fuff❄udit❄img❄79272', '16:27:12', 'udit', 'fuff', 'BQACAgUAAxkDAANDZaz4xEGa63Xp7ZUZjmPzoZQaUJcAAhsRAALuw2hVWz3GAcsS_Yg0BA'),
('103.172.73.23', 'fuff❄udit2❄img❄40331', '16:59:20', 'udit2', 'fuff', 'BQACAgUAAxkDAANEZa0AAUxEpLsxNTstetw0POehBJ5kAAIyEQAC7sNoVaB9LkA1C1gzNAQ'),
('103.172.73.23', 'fuff❄udit2❄img❄40864', '16:59:37', 'udit2', 'fuff', 'BQACAgUAAxkDAANFZa0AAV06LARYpzTAKtMKh60eNRyCAAIzEQAC7sNoVWkI1U-DI60WNAQ'),
('103.172.73.23', 'fuff❄udit2❄img❄67334', '17:02:46', 'udit2', 'fuff', 'BQACAgUAAxkDAANGZa0BGjgIB5eLSq5juQvz1jiOT9cAAjQRAALuw2hV0n3KQMiSZbg0BA'),
('103.172.73.23', 'fuff❄ayush❄vid❄87823', '17:04:49', 'ayush', 'fuff', 'BQACAgUAAxkDAANHZa0BlcSwohRGwXzn-ras_6p6tfMAAjURAALuw2hV8c_M0F8IYhs0BA'),
('103.172.73.23', 'fuff❄ayush❄vid❄87952', '17:05:18', 'ayush', 'fuff', 'BQACAgUAAxkDAANIZa0BsmvutVNleUiQAzLaUGnD5CkAAjYRAALuw2hVzhOaFp8761s0BA'),
('103.172.73.23', 'fuff❄udit2❄vid❄44288', '17:05:55', 'udit2', 'fuff', 'BQACAgUAAxkDAANJZa0B1-D3PbLHb5zgf2pCDYbOIskAAjcRAALuw2hVTEG5Rrr0p8U0BA'),
('103.172.73.23', 'fuff❄udit2❄img❄19872', '17:07:33', 'udit2', 'fuff', 'BQACAgUAAxkDAANKZa0COSnW0927l8qriZoaZ2FQ1-sAAjgRAALuw2hVUlDZGuYF7so0BA'),
('103.172.73.23', 'fuff❄udit2❄img❄66605', '17:07:57', 'udit2', 'fuff', 'BQACAgUAAxkDAANLZa0CUZXbF9BQLr1kCXtriEnWaXkAAjkRAALuw2hVQ2AvHB1BsZE0BA'),
('103.172.73.23', 'fuff❄udit2❄pdf❄82656', '17:10:40', 'udit2', 'fuff', 'BQACAgUAAxkDAANMZa0C9ZnefAH59cf3aC6ZsmvN8M4AAkARAALuw2hVT2iOwLkpiLY0BA'),
('103.172.73.23', 'fuff❄udit2❄img❄22744', '17:22:56', 'udit2', 'fuff', 'BQACAgUAAxkDAANNZa0F1M5041qwZ04QIXJAeJRHeQ8AAkMRAALuw2hV09OLPfNN5Og0BA'),
('103.172.73.23', 'fuff❄udit2❄img❄86018', '17:24:07', 'udit2', 'fuff', 'BQACAgUAAxkDAANOZa0GHBdyJGNzArN4O8wCR31JX2YAAkQRAALuw2hVE7gwVHzibTk0BA'),
('103.172.73.23', 'fuff❄udit2❄img❄92031', '17:24:46', 'udit2', 'fuff', 'BQACAgUAAxkDAANPZa0GQjQ0B_q9Nx_aH5NeISzrfA8AAkURAALuw2hV5xlf6XSzpA00BA'),
('103.172.73.23', 'fuff❄udit2❄img❄53699', '17:26:32', 'udit2', 'fuff', 'BQACAgUAAxkDAANQZa0GrLDtnzPD80-dVinsnIUGs3YAAkgRAALuw2hVCZTJSisYGq00BA'),
('103.172.73.23', 'fuff❄udit2❄img❄43552', '17:26:40', 'udit2', 'fuff', 'BQACAgUAAxkDAANRZa0GtFgooQeHG5g1RY6nD9Zd4pwAAkkRAALuw2hVNvRfUz__m-g0BA'),
('103.172.73.23', 'fuff❄udit2❄img❄65726', '17:26:51', 'udit2', 'fuff', 'BQACAgUAAxkDAANSZa0Gv6Fi1jBmb2gW4yg7noBX9e0AAkoRAALuw2hV5nTY8_zCcV80BA'),
('103.172.73.23', 'fuff❄udit2❄vid❄46755', '17:30:47', 'udit2', 'fuff', 'BQACAgUAAxkDAANTZa0HrD0xGw0sm7RS_2YK2yOi5j8AAksRAALuw2hV2-Q4Ddr3Vww0BA'),
('103.172.73.23', 'fuff❄udit2❄vid❄63952', '17:32:07', 'udit2', 'fuff', 'BQACAgUAAxkDAANUZa0H-4pxU_kWgdJZxetWbXVSnkAAAkwRAALuw2hVKyzwZD53YDE0BA'),
('103.172.73.23', 'fuff❄udit2❄vid❄80111', '17:33:04', 'udit2', 'fuff', 'BQACAgUAAxkDAANVZa0INbB6Y1iwPjQiJQ83AAE6NeDMAAJNEQAC7sNoVUkhqrzigvGgNAQ'),
('103.172.73.23', 'fuff❄udit2❄vid❄87214', '17:34:25', 'udit2', 'fuff', 'BQACAgUAAxkDAANWZa0IhQa13z60B1s6XUPWOzL3IBoAAk4RAALuw2hVqoamCpa6I0o0BA'),
('103.172.73.23', 'fuff❄udit2❄img❄88612', '17:34:34', 'udit2', 'fuff', 'BQACAgUAAxkDAANXZa0Ij9hsq5V5WkOPDLVS8lBN76UAAk8RAALuw2hVh_bPTxBmvEc0BA'),
('103.172.73.23', 'fuff❄udit2❄img❄11698', '17:36:03', 'udit2', 'fuff', 'BQACAgUAAxkDAANYZa0I58jwl8S9mqtGKHj7wQpYYd0AAlIRAALuw2hVSDkhNFQ96Ak0BA'),
('103.172.73.23', 'fuff❄udit2❄pdf❄95553', '17:36:54', 'udit2', 'fuff', 'BQACAgUAAxkDAANZZa0JGq15W65BmiGUo1GLetGaYeYAAlMRAALuw2hVLzNwQExsAYc0BA'),
('103.172.73.23', 'fuff❄udit2❄pdf❄61959', '17:39:10', 'udit2', 'fuff', 'BQACAgUAAxkDAANaZa0JohcuI8E_rK4RZm09pYXlJSgAAlQRAALuw2hVoHc6k5PDnRc0BA'),
('103.172.73.23', 'fuff❄udit2❄pdf❄88368', '17:40:01', 'udit2', 'fuff', 'BQACAgUAAxkDAANbZa0J1iOkeWt-W_T7QsHi9MC63XQAAlURAALuw2hVGrd7CnY3VHQ0BA'),
('103.172.73.23', 'hello', '18:21:00', 'udit', 'ch1gj', NULL),
('103.172.73.23', 'hi', '18:29:38', 'udit', 'ykyy', NULL),
('103.172.73.23', 'hlo', '18:29:43', 'udit', 'ykyy', NULL),
('103.172.73.23', 'hi', '18:29:47', 'ykyy', 'ykyy', NULL),
('103.172.73.23', 'ykyy❄ykyy❄vid❄80791', '18:29:54', 'ykyy', 'ykyy', 'BQACAgUAAxkDAANcZa0Vhoi2NI-WoJ-eNZxpdc97L9wAAl4RAALuw2hVEA9WntOj8lU0BA'),
('103.172.73.23', 'ykyy❄ykyy❄vid❄87249', '18:30:08', 'ykyy', 'ykyy', 'BQACAgUAAxkDAANdZa0VlP6yIY3MpD6mQfiT785nZicAAl8RAALuw2hVtqdpW2qgGz80BA'),
('103.172.73.23', 'hi', '14:17:42', 'udit', 'chat000ge', NULL),
('103.172.73.120', 'chat000❄udit❄img❄89467', '16:58:04', 'udit', 'chat000', 'BQACAgUAAxkDAANvZeRfNtaAhz2QQDahEztumgJRXAkAAnQOAAJMlSFXlT47wSKrplE0BA'),
('103.172.73.120', 'chat000❄udit❄vid❄89943', '17:03:17', 'udit', 'chat000', 'BQACAgUAAxkDAANwZeRgbxs9Z--tAV60evEvsTIt8WgAAnYOAAJMlSFX1d9pMCat11Q0BA'),
('103.172.73.179', 'chat000❄udit❄vid❄98761', '13:53:27', 'udit', 'chat000', 'BQACAgUAAxkDAANxZel59plq_qKJ00VuJZKUe4TLs24AAuUNAAKP1FBX4ezU82Km8WU0BA'),
('103.172.73.179', 'hi', '14:48:54', 'y', 'ffffd', NULL),
('223.225.91.106', 'hlo', '15:03:59', 'vc', 'ffffd', NULL),
('223.225.91.106', 'ffffd❄vc❄img❄18455', '15:04:14', 'vc', 'ffffd', 'BQACAgUAAxkDAANyZemKjZlOxNffYyDqGMpDEODfZnkAAn8OAAKP1FBXNaZAMc9sXFE0BA'),
('223.225.91.106', 'ffffd❄vc❄vid❄71498', '15:07:13', 'vc', 'ffffd', 'BQACAgUAAxkDAANzZemLQOFamnxWK_gLb9iZLXUcE4IAAoUOAAKP1FBXdgK4hT6-T4M0BA'),
('223.225.91.106', 'hi', '15:09:47', 'vc', 'ffffd', NULL),
('223.225.91.106', 'hi', '15:09:59', 'vc', 'ffffd', NULL),
('223.225.91.106', 'hi', '15:10:17', 'vc', 'ffffd', NULL),
('223.225.91.106', 'hi', '15:11:45', 'vc', 'ffffd', NULL),
('103.172.73.179', 'ffffd❄udit❄vid❄54766', '15:12:45', 'udit', 'ffffd', 'BQACAgUAAxkDAAN0ZemMjMEl_TnH1ZUzto4SVvri7V0AAocOAAKP1FBX0IIdYl6fS7A0BA'),
('223.225.91.106', 'hi', '15:13:03', 'vc', 'ffffd', NULL),
('223.225.88.250', 'guif', '16:36:39', 'udit', 'uditgdg5', NULL),
('106.221.224.121', 'hi', '14:16:55', 'udit', 'room', NULL),
('106.221.224.121', 'Lund', '14:17:04', 'Ayush', 'room', NULL),
('106.221.224.121', 'Muskan ayush ki Mommy', '14:19:22', 'Ayush', 'room', NULL),
('106.221.224.121', 'Rajesh ayush ke dada', '14:19:58', 'Ayush', 'room', NULL),
('106.221.224.121', 'Udit ayush ke papa', '14:20:16', 'Ayush', 'room', NULL),
('106.221.224.121', 'room❄Ayush❄vid❄16713', '14:24:13', 'Ayush', 'room', 'BQACAgUAAxkDAAN1ZfK7tv_uIuEjCw1U3MSoHUnM0pQAAtINAAIOdphX93kHED3xbrE0BA'),
('103.172.73.179', 'chat00023r32❄test❄img❄41621', '23:09:19', 'test', 'chat00023r32', 'BQACAgUAAxkDAAN2Zj-uLiC_wEta3_ceGEno5BBnnA0AArEPAAJciPhVEYyA46931hk1BA'),
('27.59.79.117', 'ayy', '17:09:48', 'ayush', '123', NULL),
('27.59.79.117', 'ramm ram', '17:10:03', 'raju', '123', NULL),
('106.221.230.23', 'hiii', '14:24:30', 'udit', '12341', NULL),
('106.221.230.23', 'hello', '14:24:41', 'udit', '12341', NULL),
('106.221.230.23', 'hi', '14:25:45', 'abccc', '12341', NULL),
('106.221.230.23', 'hi', '14:53:16', 'udit', 'chat00011', NULL),
('106.221.230.23', 'chat00011❄udit❄img❄75985', '14:54:37', 'udit', 'chat00011', 'BQACAgUAAxkDAAN4ZkSARG7h9n0K8uPbwz_kTfOrqIAAAgUPAAIluyBWglO_sFZPmTQ1BA');

-- --------------------------------------------------------

--
-- Table structure for table `reg`
--

CREATE TABLE `reg` (
  `ip` varchar(255) NOT NULL,
  `owner_name` varchar(50) NOT NULL,
  `room_name` varchar(50) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reg`
--

INSERT INTO `reg` (`ip`, `owner_name`, `room_name`, `password`) VALUES
('106.221.230.23', 'udit', '12341', '$2y$10$.b.UtFM9thy3goyvVB9iweMfyzFRYLTBNc5EpU5THSNqF9AWH8ll.'),
('103.172.73.48', '123', '123rg', '$2y$10$bdmLMO.YBwEMdzoeMHDKEuRcjemUlouxVPySigQ7TiPQFHjnjEcNG'),
('', 'raam', '9911', '$2y$10$5CvGzsCqAzqpSvkOhk6kbulyTnRsVbpw/lQBudNFYjGULZj9VSIFC'),
('', 'rrr', '999', '$2y$10$3lPCOc9u25K04e/tIPirt.lkBmRzi4OsiOs2Kl068FP3DYi1p8wZC'),
('', 'aaaa', 'abcx', '$2y$10$PZbyRihyIkQjoc7O7z94PO7Y9Ba6HoA7SlNaRO9jR5llsg5dUilTO'),
('223.225.90.154', 'udit', 'c', '$2y$10$N/XdOao1BpQDWc5HoyEki.fpfY9brupu79ctP8QWVrx0BObmd0cF.'),
('103.172.73.181', 'fu', 'ch1', '$2y$10$KNiM6/TpMriDALfGIBOAcO34x.LBl9aUYB1c9spfdE1FV31.GQW/.'),
('103.172.73.181', 'fu', 'ch12', '$2y$10$rVmJGyb2vEHPbmaJN8iu0.jvqKj8jKtqsyS/x37fSlSbXP2hzRImm'),
('106.221.224.121', 'udit', 'chat', '$2y$10$XSj4.0.aUeXUc9IlpVZLi.xQFGyO2.8iNm1.9n0Xi3wGzmmI9LKrS'),
('103.172.73.210', 'udit', 'chat000', '$2y$10$IGaw/yCyrkPFpDSMQT4tt.WyLqx6/VSncIfNG.IErHqLxvRALrzwi'),
('103.172.73.179', 'udit', 'chat00023r32', '$2y$10$3Jlic9ev292JaX.z3pq.nOSeyb0X8HroYrK6Xtgf6AFQPh1iwIeoq'),
('103.172.73.210', 'udit', 'chat000d', '$2y$10$vg3vabLrrSg6DoExy3f/LOrvNelkz6457Mk8Y6Tj11iomAclXgrta'),
('103.172.73.181', 'udit', 'chat000ds', '$2y$10$ZsCJS4UNyYl4FE0KwPoxNeUS79jK.Dt3tYtqPzR2hM992tF6HbljC'),
('', 'udit', 'chat000eve', '$2y$10$5JOfiJo5P6zJDcJCqXHN0OCYhb78uhsY3l6eczIWo4oNcqYzbAzGy'),
('103.172.73.210', 'udit', 'chat000f', '$2y$10$IRbSm.rIOpf1rOhJPD9N/uy/nqpmXymxcvpx9p0gbk7fyLndWeraK'),
('103.172.73.23', 'udit', 'chat000ge', '$2y$10$t6b92mNMPSi2TbJi5zFOmui9fitheTFTbH2wBnfgGZ/hyLbSPkUoa'),
('103.172.73.179', 'udit', 'chat000t5tt', '$2y$10$O.MWobhEZxDB2DCLuSoi9OuXNEeFDw4Haa5L84mOB.wtg9e5cVUZW'),
('103.172.73.181', 'udit', 'chat000th', '$2y$10$yz1N77aQuVRwaMCOch31ueToq7x0HDohJbY9fMg4/WdH.Cji3jASe'),
('103.172.73.60', 'udit', 'chat000tyh', '$2y$10$Lj9O.8SFn7tV3DV1alkf6.rb2PpaCal3QLhldMr.ZbHH9bpkt9l2S'),
('103.172.73.184', 'udit', 'chat1231', '$2y$10$b.sZJhefPS2dPhIAfcUeFO7v6bEBtcuJBBTF6K5UqMzBNQIFR8Iki'),
('103.172.73.100', 'udit', 'chat6', '$2y$10$kst3N5WHaJrid2Bgn7zCdeW/m0Q8T0ZomMS8EvTdwzcU2baceuyw2'),
('103.172.73.179', 'udit', 'chat9999', '$2y$10$9pNCPuQnT0Fwu/0nZM..UuAt1EfjZ7Rvzgu0aEVbrukHGPzM7k1JW'),
('103.172.73.184', 'udit', 'chatd', '$2y$10$5sn2LO/KSZC5K2wEbdw7U.PIfXszCprUNrzom6WAe5i4kbHzUmL4u'),
('103.172.73.210', 'udit', 'chatf', '$2y$10$uCipL9M11MBnAaE59poO2OiaqVcu76C.Eq1ihrAsjoK/z0JRLz9Mm'),
('103.172.73.179', 'udit', 'chathh', '$2y$10$9V8yd6Ymp30665kN8bPZ6.53yADnxmWbK5pz0fZXDcTV.Ab3GUDNe'),
('103.172.73.184', 'udit', 'chatjg', '$2y$10$weGQybkKIev4j2JOCUi11O4A0pjDiUVm3ZaoY5W74c3I3uwEsv3ci'),
('103.172.73.181', 'udit', 'chatr', '$2y$10$yNP/j6uAKMOHJZHLijbwg.6iDkKM/awFAzIWMHZp7q2jj7vzMUrhy'),
('103.172.73.179', 'udit', 'ffffd', '$2y$10$oRabT2xesNBg9Vztnfvs8ubjkYRyOLzz8Un.b6KlY7NKIw6wHq8..'),
('103.172.73.23', 'udit', 'fuff', '$2y$10$QXyn2YLfx8yeSmcTiPN3IekztxEMUnfC.tZwGQovbgYCMEsoLYD3G'),
('103.172.73.120', 'udit', 'fuffef', '$2y$10$RWNXdeLetgW9Lg1ba4Z5hOudO/Mh0GfaIz7gG2u06WpigG6KYuwBC'),
('106.221.230.23', 'ram', 'ram123', '$2y$10$QAZ6AfypjG.32HAa.MIeyuqlpDYsdSEcI7xGIdRFxXbWtSH3KwYPa'),
('106.221.224.121', 'udit', 'room', '$2y$10$v7cz.hoe/lEVDMTN/q/Mk.zOIu2l7q/EiIs.vNdidlCCKOpy/ye8u'),
('103.172.73.181', 'udit', 'ryy', '$2y$10$uQ13nQUp2DzkH6HlTHxhO.adVVwLsZms0S66Ia0S8oED2I7FeyJBC'),
('106.221.230.23', 'udit', 'trail234', '$2y$10$2WEey36z68hLQaPQjAdfbOhknCF5HHmnisaeXrnU4lsQ91Ab5cJzW'),
('106.221.239.176', 'udit', 'trial11', '$2y$10$XJfxFmMnNe2QA3iIdPuZi.1uKKLxhrPHSBvwmrchH2D9NMlkQhHi6'),
('223.225.88.250', 'udit', 'utf', '$2y$10$Sh/q01aj9Svvid9fOiA1wO3y4PCgHtUQNnZQRo4n7.8R0MEB/YwQW'),
('103.172.73.48', 'efewf', 'wefwef', '$2y$10$zZqZ8z/WjsqQoA2dHBtoLu2tBZ/cBROdpWfErFOqjgalMylgnGYWq');

-- --------------------------------------------------------

--
-- Table structure for table `removed`
--

CREATE TABLE `removed` (
  `name` varchar(255) NOT NULL,
  `ip` varchar(255) NOT NULL,
  `room` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `removed`
--

INSERT INTO `removed` (`name`, `ip`, `room`) VALUES
('u13ew', '103.172.73.210', 'chat000'),
('hreggecewh', 'rthergeheh', 'chat000f'),
('uditf', '223.225.90.154', 'chat000f'),
('u13e', '103.172.73.210', 'chat'),
('udit', '103.172.73.210', 'ch1'),
('udit', '103.172.73.181', 'ch12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ip` varchar(255) NOT NULL,
  `room_id` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `last_login` varchar(200) NOT NULL,
  `removed` varchar(255) NOT NULL DEFAULT 'not',
  `call_id` varchar(255) NOT NULL DEFAULT 'not'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ip`, `room_id`, `username`, `last_login`, `removed`, `call_id`) VALUES
('103.172.73.184', 'chat1231', 'cvbd', '1705242011', 'not', ''),
('103.172.73.23', 'ch1gj', 'fu', '1705841454', 'not', ''),
('103.172.73.179', 'ffffd', 'ayush', '1709803947', 'not', ''),
('103.172.73.179', 'ffffd', 'fg', '1709803881', 'not', ''),
('103.172.73.179', 'ffffd', 'vc', '1709809854', 'not', ''),
('103.172.73.210', 'gd', 'udit', '1709876791', 'not', ''),
('103.172.73.210', 'chat000', 'udit', '1709977738', 'not', ''),
('103.172.73.210', 'chat000f', 'udit', '1710052101', 'not', ''),
('223.225.88.250', 'utf', 'udit', '1709982214', 'not', ''),
('223.225.88.250', 'uditgdg5', 'udit', '1709982408', 'not', ''),
('223.225.90.154', 'chat000f', 'chat', '1709984137', 'not', ''),
('223.225.90.154', 'chat000f', 'chatg', '1709984194', 'not', ''),
('223.225.90.154', 'chat000f', 'uditf', '1709984236', 'removed', ''),
('223.225.90.154', 'c', 'udit', '1709984771', 'not', ''),
('103.172.73.210', 'c', 'uditf', '1709984355', 'not', ''),
('103.172.73.210', 'c', 'uditd', '1709984510', 'not', ''),
('103.172.73.210', 'chatf', 'udit', '1709984888', 'not', ''),
('103.172.73.210', 'chat000f', 'u13e', '1709984886', 'removed', ''),
('103.172.73.210', 'chat000d', 'udit', '1710052584', 'not', ''),
('103.172.73.210', 'chat000d', 'u13e', '1710052565', 'removed', ''),
('106.221.224.121', 'room', 'udit', '1710406453', 'not', ''),
('106.221.224.121', 'room', 'Ayush', '1710406477', 'not', ''),
('106.221.224.121', 'chat', 'udit', '1710407911', 'not', ''),
('106.221.224.121', 'chat', 'u13e', '1710406799', 'removed', ''),
('103.172.73.181', 'chat000ds', 'udit', '1710572145', 'not', ''),
('103.172.73.181', 'erg', 'udit', '1710572224', 'not', ''),
('103.172.73.181', 'ch1', 'fu', '1710572786', 'not', ''),
('103.172.73.181', 'ch1', 'udit', '1710572843', 'not', ''),
('103.172.73.181', 'ch12', 'fu', '1710579328', 'not', ''),
('103.172.73.181', 'ch12', 'cc', '1710573672', 'not', ''),
('103.172.73.181', 'ch12', 'udit', '1710575117', 'removed', ''),
('103.172.73.181', 'chatr', 'udit', '1710583974', 'not', 'hii'),
('103.172.73.181', 'chatr', 'u13e', '1710584234', 'not', '1229'),
('103.172.73.181', 'chatr', 'udit2', '1710584519', 'not', 'not'),
('103.172.73.181', 'chatr', 'u13er', '1710584558', 'not', 'not'),
('103.172.73.181', 'chatd', 'udit', '1710611111', 'not', 'not'),
('103.172.73.181', 'chatd', 'u13er', '1710610236', 'not', 'not'),
('117.98.8.83', 'chatd', 'chattt', '1710610967', 'not', 'not'),
('117.98.8.83', 'chatd', 'dd', '1710611402', 'not', 'not'),
('103.172.73.181', 'chatd', 'cvbd', '1710611278', 'not', 'not'),
('103.172.73.181', 'chatd', 'u13e', '1710611806', 'not', 'not'),
('103.172.73.181', 'chat000th', 'udit', '1710611343', 'not', 'not'),
('103.172.73.181', 'ryy', 'udit', '1710611805', 'not', 'not'),
('', 'ryy', 'dd', '1710611810', 'not', 'not'),
('103.172.73.100', 'chat6', 'udit', '1710665597', 'not', 'not'),
('103.172.73.48', 'wefwef', 'efewf', '1714197935', 'not', 'not'),
('103.172.73.48', '123rg', '123', '1714197962', 'not', 'not'),
('103.172.73.179', 'chat000t5tt', 'udit', '1715447564', 'not', 'not'),
('103.172.73.179', 'chat00023r32', 'udit', '1715450853', 'not', 'not'),
('103.172.73.179', 'chat00023r32', 'test', '1715449363', 'not', 'not'),
('103.172.73.179', 'chat9999', 'udit', '1715450048', 'not', 'not'),
('103.172.73.179', 'chathh', 'udit', '1715450857', 'not', 'not'),
('27.59.79.117', '123', 'ayush', '1715686922', 'not', 'not'),
('', '123', 'raju', '1715686845', 'removed', 'not'),
('', '9911', 'raam', '1715759772', 'not', 'not'),
('', '9911', 'ramesh', '1715759748', 'not', 'not'),
('106.221.239.176', 'trial11', 'udit', '1715761041', 'not', 'not'),
('106.221.239.176', 'trial11', 'Ayush', '1715760615', 'not', 'not'),
('106.221.234.23', 'trial11', 'Abc', '1715760982', 'not', 'not'),
('', '123', 'raj', '1715761550', 'not', 'not'),
('106.221.234.23', '123', 'mahi', '1715761449', 'removed', 'not'),
('', '123', 'raja', '1715762552', 'not', 'not'),
('', '999', 'rrr', '1715763152', 'not', 'not'),
('', '999', 'jjj', '1715763188', 'not', 'not'),
('', 'chat000eve', 'udit', '1715763218', 'not', 'not'),
('', 'abcx', 'aaaa', '1715763217', 'not', 'not'),
('106.221.230.23', '12341', 'udit', '1715763417', 'not', 'not'),
('106.221.230.23', '12341', 'abccc', '1715763418', 'not', 'not'),
('106.221.230.23', 'trail234', 'udit', '1715764957', 'not', 'not'),
('106.221.230.23', 'chat00011', 'udit', '1715765172', 'not', 'not'),
('106.221.230.23', 'chat00011', 'Ayush', '1715765179', 'not', 'not'),
('106.221.230.23', 'ram123', 'ram', '1715765798', 'not', 'not');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reg`
--
ALTER TABLE `reg`
  ADD PRIMARY KEY (`room_name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
