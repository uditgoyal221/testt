document.getElementById('menuButton').addEventListener('click', function(event) {
    const popupMenu = document.getElementById('popupMenu');
    popupMenu.classList.toggle('open');

    // Calculate position based on menu button
    const menuButton = document.getElementById('menuButton');
    const rect = menuButton.getBoundingClientRect();
    popupMenu.style.top = rect.top + menuButton.offsetHeight + 'px';
    popupMenu.style.left = rect.left + 'px';

    event.stopPropagation(); // Prevent this click from closing the menu immediately
});

document.addEventListener('click', function(event) {
    const popupMenu = document.getElementById('popupMenu');
    if (popupMenu.classList.contains('open')) {
        popupMenu.classList.remove('open');
    }
});

document.getElementById('popupMenu').addEventListener('click', function(event) {
    event.stopPropagation(); // Prevent clicks inside the menu from closing it
});
