<?php
session_start();
include ("connection.php");
$uname=$_SESSION['uname'];
$room=$_SESSION['code'];
$ip =$_SESSION['ip'];
$q ="delete from reg WHERE room_name = '$room' AND owner_name='$uname' AND ip='$ip'";
$q1="delete from removed WHERE room = '$room'";
$run_q=mysqli_query($conn,$q);
$run_q1=mysqli_query($conn,$q1);
unset($_SESSION['code'],$_SESSION['pwd']);
?><script>
    location.replace("index.php")
</script>
<?php
die();
?>