<?php
session_start();
include("connection.php");
$user = $_SESSION['uname'];
$room = $_SESSION['code'];
$ip = $_SESSION['ip'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Video Conferencing</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
            background-color: #f0f0f0;
        }

        .container {
            display: flex;
            flex-direction: row;
            justify-content: center;
            align-items: center;
        }

        .video-wrapper {
            position: relative;
            margin: 10px;
            border-radius: 8px;
            overflow: hidden;
        }

        video {
            width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .controls {
            margin-top: 20px;
        }

        .button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-right: 10px;
        }

        .button:hover {
            background-color: #0056b3;
        }

        .disconnect {
            background-color: #dc3545;
        }

        .disconnect:hover {
            background-color: #c82333;
        }

        .local-popup {
            position: absolute;
            top: 20px;
            left: 20px;
            z-index: 1000;
            cursor: move;
        }

        .mute-icon {
            position: absolute;
            bottom: 10px;
            right: 10px;
            background-color: rgba(0, 0, 0, 0.5);
            color: #fff;
            padding: 5px;
            border-radius: 50%;
            display: none;
        }

        .video-wrapper.video-muted .mute-icon {
            display: block;
        }
    </style>
</head>

<body>

    <div class="container">
        <div class="video-wrapper" id="localVideoContainer">

            <video id="localVideo" autoplay muted></video>
            <div class="local-popup" draggable="true"><i id="mute" class='fas fa-volume-mute' style='font-size:48px;color:red;display:none;'></i></div>
            <div class="mute-icon" id="localMuteIcon">&#128263;</div>
        </div>
        <div class="video-wrapper" id="remoteVideoContainer">
            <video id="remoteVideo" autoplay></video>
        </div>
    </div>
    <div class="controls">
        <button id="videobtn" class="button" onclick="toggleLocalVideo()">Pause My Video</button>
        <button id="audiobtn" class="button" onclick="toggleLocalAudio()">Mute My Audio</button>
        <button id="screensharebtn" class="button" onclick="toggleScreenShare()">Share Screen</button>
        <button class="button disconnect" onclick="back()">Disconnect</button>
    </div>

    <script type='text/javascript' src='https://cdn.scaledrone.com/scaledrone.min.js'></script>
    <script>
        var params = new URLSearchParams(window.location.search);
        const roomHash = params.get('callcode');

        const drone = new ScaleDrone('xAANVu8G53dPz74F');
        const roomName = 'observable-' + roomHash;
        const configuration = {
            iceServers: [{
                urls: 'stun:stun.l.google.com:19302'
            }]
        };
        let room;
        let pc;
        let isLocalVideoPaused = false;
        let isLocalAudioMuted = false;
        let remoteConnectionEstablished = false;
        let remoteConnectionTimer;
        let isScreenSharing = false;
        let screenStream = null;
        let localStream = null; // Added to keep track of the current local stream

        function onSuccess() {};
        function onError(error) {
            console.error(error);
        };

        drone.on('open', error => {
            if (error) {
                return console.error(error);
            }
            room = drone.subscribe(roomName);
            room.on('open', error => {
                if (error) {
                    onError(error);
                }
            });
            room.on('members', members => {
                console.log('MEMBERS', members);
                const isOfferer = members.length > 1;
                startWebRTC(isOfferer);

                remoteConnectionTimer = setTimeout(() => {
                    if (!remoteConnectionEstablished) {
                        window.location.href = 'chat_app.php'; // Change the URL to your redirect page
                    }
                }, 10000); // 10 seconds
            });
        });

        function sendMessage(message) {
            drone.publish({
                room: roomName,
                message
            });
        }

        function startWebRTC(isOfferer) {
            pc = new RTCPeerConnection(configuration);

            pc.onicecandidate = event => {
                if (event.candidate) {
                    sendMessage({ 'candidate': event.candidate });
                }
            };

            if (isOfferer) {
                pc.onnegotiationneeded = () => {
                    pc.createOffer().then(localDescCreated).catch(onError);
                }
            }

            pc.ontrack = event => {
                const stream = event.streams[0];
                if (!remoteVideo.srcObject || remoteVideo.srcObject.id !== stream.id) {
                    remoteVideo.srcObject = stream;
                    clearTimeout(remoteConnectionTimer);
                    remoteConnectionEstablished = true;
                    
                    stream.getTracks().forEach(track => {
                        track.onended = () => {
                            window.location.href = 'chat_app.php'; // Change the URL to your redirect page
                        };
                    });
                }
            };

            navigator.mediaDevices.getUserMedia({
                audio: true,
                video: true,
            }).then(stream => {
                localStream = stream; // Store the local stream
                localVideo.srcObject = stream;
                stream.getTracks().forEach(track => pc.addTrack(track, stream));
            }, onError);

            room.on('data', (message, client) => {
                if (client.id === drone.clientId) {
                    return;
                }

                if (message.sdp) {
                    pc.setRemoteDescription(new RTCSessionDescription(message.sdp), () => {
                        if (pc.remoteDescription.type === 'offer') {
                            pc.createAnswer().then(localDescCreated).catch(onError);
                        }
                    }, onError);
                } else if (message.candidate) {
                    pc.addIceCandidate(
                        new RTCIceCandidate(message.candidate), onSuccess, onError
                    );
                }
            });
        }

        function localDescCreated(desc) {
            pc.setLocalDescription(
                desc,
                () => sendMessage({ 'sdp': pc.localDescription }),
                onError
            );
        }

        function toggleLocalVideo() {
            if (isLocalVideoPaused) {
                localVideo.srcObject.getVideoTracks().forEach(track => track.enabled = true);
                isLocalVideoPaused = false;
                document.getElementById('videobtn').textContent = "Pause My Video";
            } else {
                localVideo.srcObject.getVideoTracks().forEach(track => track.enabled = false);
                isLocalVideoPaused = true;
                document.getElementById('videobtn').textContent = "Unpause My Video";
            }
        }

        function toggleLocalAudio() {
            const audioButton = document.getElementById('audiobtn');
            if (isLocalAudioMuted) {
                document.getElementById("mute").style.display = 'none';
                localVideo.srcObject.getAudioTracks().forEach(track => track.enabled = true);
                isLocalAudioMuted = false;
                audioButton.textContent = "Mute My Audio";
                document.getElementById('localVideoContainer').classList.remove('video-muted');
            } else {
                document.getElementById("mute").style.display = 'block';
                localVideo.srcObject.getAudioTracks().forEach(track => track.enabled = false);
                isLocalAudioMuted = true;
                audioButton.textContent = "Unmute My Audio";
                document.getElementById('localVideoContainer').classList.add('video-muted');
            }
        }

     
async function toggleScreenShare() {
    const screenshareButton = document.getElementById('screensharebtn');
    
    try {
        if (!isScreenSharing) {
            screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
            startScreenSharing(screenStream);
            isScreenSharing = true;
            screenshareButton.textContent = 'Stop Sharing';
        } else {
            switchToCameraVideo();
            isScreenSharing = false;
            screenshareButton.textContent = 'Share Screen';
        }
    } catch (error) {
        console.error('Error sharing screen:', error);
    }
}

function startScreenSharing(stream) {
    // Replace video track with screenStream
    replaceVideoTrack(stream);
}

function switchToCameraVideo() {
    // Replace video track with localStream (camera)
    navigator.mediaDevices.getUserMedia({
    video: true,
    audio: true
}).then(stream => {
    localStream = stream;
}).catch(error => {
    console.error('Error accessing camera:', error);
});
localVideo.srcObject = localStream;
localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
}

function replaceVideoTrack(newStream) {
    const videoTracks = localVideo.srcObject ? localVideo.srcObject.getVideoTracks() : [];
    if (videoTracks.length > 0) {
        videoTracks.forEach(track => track.stop()); // Stop current video tracks
    }
    
    // Add new video tracks
    const newTracks = newStream.getVideoTracks();
    if (localVideo.srcObject) {
        localVideo.srcObject.addTrack(newTracks[0]);
    } else {
        localVideo.srcObject = newStream;
    }
    
    // Update senders with new tracks
    pc.getSenders().forEach(sender => {
        if (sender.track.kind === 'video') {
            sender.replaceTrack(newTracks[0]);
        }
    });
}

// Initialize localStream (camera)





        function back(){
            window.history.back();
        }
    </script>
</body>

</html>
