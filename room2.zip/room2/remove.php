<?php
session_start();
include ("connection.php");
$user=$_POST['username'];
$uname=$_SESSION['uname'];
$room=$_SESSION['code'];
$ip =$_SESSION['ip'];
$q1 = "UPDATE users SET removed='removed' WHERE username ='$user' and room_id='$room'";
$c_q="select ip from users where username ='$user' and room_id ='$room'";


$q ="select * from reg WHERE room_name = '$room' AND owner_name='$uname' AND ip='$ip'";
$run_q=mysqli_query($conn,$q);
$num = mysqli_num_rows($run_q);
if($num==1){
    $run_2=mysqli_query($conn,$c_q);
    $resu=mysqli_fetch_assoc($run_2);
    $ipp=$resu['ip'];
    $q0=mysqli_query($conn,"INSERT INTO `removed`(`name`,`ip`, `room`) VALUES ('$user','$ipp','$room')");
    $run_q=mysqli_query($conn,$q1);
}
?>