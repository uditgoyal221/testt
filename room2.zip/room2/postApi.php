<?php

// Replace 'YOUR_BOT_TOKEN' with your actual bot token
$botToken = '6814467734:AAEX_J6KF2Lc--KTsTm88Arb8kw8_kqglb4';

// Replace 'YOUR_CHAT_ID' with the actual chat ID where you want to send the file
$chatId = '5483244664';

// Set the path to the file you want to send
$filePath = 'C:/xampp/htdocs/Chatroom/a.txt';

// Telegram API endpoint for sending files
$apiEndpoint = "https://api.telegram.org/bot{$botToken}/sendDocument";

// Build the cURL request
$curlFile = new CURLFile(realpath($filePath));
$postFields = [
    'chat_id' => $chatId,
    'document' => $curlFile,
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiEndpoint);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute cURL request
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch);
} else {
    // Decode and print the response
    $decodedResponse = json_decode($response, true);
    print_r($decodedResponse);
}

// Close cURL session
curl_close($ch);
?>
