<?php
session_start();
include ("connection.php");
if (!isset($_SESSION['code']) && !isset($_SESSION['pwd']) && !isset($_SESSION['uname'])) {
    ?><script>
    location.replace("index.php")
</script>
<?php
die();
  } 
  if(!isset($_POST['bcode'])){
    $room=$_SESSION['code'];
    $msg=$_POST['usermsg'];
    $uname=$_SESSION['uname'];
    $ip=$_POST['ip'];
    $query="INSERT INTO `msg` (`msg`, `room`, `ip`,`uname`) VALUES ( '$msg', '$room', '$ip','$uname');";
    $run_q=mysqli_query($conn,$query);

  }else{
    $room=$_SESSION['code'];
    $code=$_POST['bcode'];
    $msg="abc";
    $uname=$_SESSION['uname'];
    $ip=$_POST['ip'];
    $random=rand(9999,99999);
    $filename = $_POST['code'].'❄'.$_POST['uname'].'❄'.$_POST['type'].'❄'.$random. '.txt';
    $file = $_POST['code'].'❄'.$_POST['uname'].'❄'.$_POST['type'].'❄'.$random;

    $botToken = '6814467734:AAEX_J6KF2Lc--KTsTm88Arb8kw8_kqglb4';
    $chatId = '5483244664';
    $directory = 'C:\\xampp\\htdocs\\database\\';

    $filePath = $directory . $filename;
    file_put_contents($filePath, $code);

    $apiEndpoint = "https://api.telegram.org/bot{$botToken}/sendDocument";

    // Build the cURL request
    $curlFile = new CURLFile(realpath($filePath));
    $postFields = [
        'chat_id' => $chatId,
        'document' => $curlFile,
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiEndpoint);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    // Execute cURL request
    $response = curl_exec($ch);
    
    // Check if the message was sent successfully
    $telegramDecodedResponse = json_decode($response, true);
    if ($telegramDecodedResponse['ok'] === true) {
        // Retrieve the file ID from the API response
        $fileId = $telegramDecodedResponse['result']['document']['file_id'];

        // Your existing code to insert message into the database
        $query="INSERT INTO `msg` (`msg`, `room`, `ip`,`uname`,`fcode`) VALUES ( '$file', '$room', '$ip','$uname','$fileId');";
        $run_q=mysqli_query($conn,$query);
        echo "Done";
    
    } else {
        // Handle the error, if any
        echo 'Error sending message to Telegram: ' . $telegramDecodedResponse['description'];
    }

    curl_close($ch);

}

mysqli_close($conn);
?>


