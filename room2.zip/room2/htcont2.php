<?php
session_start();
$room = $_POST['room'];
include('connection.php');

if (isset($_SESSION['uname']) && isset($_SESSION['code'])) {
    $uname = $_SESSION['uname'];
    $code = $_SESSION['code'];
    $msg = $_POST['check'];
} else {
    die();
}

$temp = 1;
$s = "SELECT * FROM users WHERE room_id='$code'";
$run = mysqli_query($conn, $s);

while ($row = mysqli_fetch_assoc($run)) {
    if ($row['username'] == $uname) {
        $temp = 1;
    }
}

if ($temp == 1) {
    $sql = "SELECT msg, stime, uname, fcode FROM msg WHERE room='$room'";
    $res = "";
    $result = mysqli_query($conn, $sql);
    $t = 1;
    $t1 = 0;

    if ($result !== false && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            if ($t <= $msg) {
                $t++;
                continue;
            }

            $filePattern = '/^(.*?)❄([^❄]+)❄([a-zA-Z]+)❄(\d+)$/';

            if (isset($row['fcode']) && preg_match($filePattern, $row['msg'], $matches)) {
                 
                
                if ($matches[3] == 'img') {
                        $imagePath = "/room1/icon.gif";
                        $ress = '<img class="img0" id="'.$row['fcode'].'" src="' . $imagePath . '" alt="Image" width="200px" height="200" onclick="downloadFile(this)">';
                    } elseif ($matches[3] == 'pdf') {
                        $imagePath = "/room1/icon2.gif";
                        $ress = '<img class ="pdf" id="'.$row['fcode'].'" src="' . $imagePath . '" alt="Image" width="280px" height="250" onclick="downloadFile(this)">';
                    } elseif ($matches[3] == 'vid') {
                        $imagePath = "/room1/icon3.png";
                        $ress = '<img class ="vid" id="'.$row['fcode'].'" src="' . $imagePath . '" alt="Image" width="280px" height="250" onclick="downloadFile(this)">';

                    }
               
            } else {
                $ress = (isset($row['uname']) && $row['uname'] == $_SESSION['uname']) ?
                    '<div class="message other-message float-right">' . $row['msg'] . '</div>' :
                    '<div class="message my-message">' . $row['msg'] . '</div>';
            }

            if (isset($row['uname']) && $row['uname'] == $_SESSION['uname']) {
                $res .= ' <li class="clearfix">
                            <div class="message-data text-right">
                                <span class="message-data-time">' . $row['uname'] . ' | ' . $row['stime'] . '</span>
                                <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar">
                            </div>
                            <div class="message other-message float-right">' . $ress . '</div>
                        </li><br>';
            } else {
                $res .= ' <li class="clearfix">
                            <div class="message-data">
                                <span class="message-data-time">' . $row['uname'] . ' | ' . $row['stime'] . '</span>
                                <img src="https://bootdey.com/img/Content/avatar/avatar7.png" alt="avatar">
                            </div>
                            <div class="message my-message">' . $ress . '</div>
                        </li><br>';
            }

            $t++;
            $t1++;
        }
    }

    echo $res;
    $temp = 0;
}

function getTelegramFileLink($fileId)
{
    $botToken = '6814467734:AAEX_J6KF2Lc--KTsTm88Arb8kw8_kqglb4';
    $apiEndpoint = "https://api.telegram.org/bot{$botToken}/getFile";

    // Build the cURL request
    $postFields = ['file_id' => $fileId];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiEndpoint);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Execute cURL request
    $response = curl_exec($ch);

    // Check for errors
    if (curl_errno($ch)) {
        return ''; // Return empty string on error
    } else {
        // Decode and extract the file path
        $decodedResponse = json_decode($response, true);

        if (isset($decodedResponse['ok']) && $decodedResponse['ok'] === true && isset($decodedResponse['result']['file_path'])) {
            return file_get_contents("https://api.telegram.org/file/bot{$botToken}/{$decodedResponse['result']['file_path']}");
        } else {
            return ''; // Return empty string on invalid response
        }
    }

    // Close cURL session
    curl_close($ch);
}
?>