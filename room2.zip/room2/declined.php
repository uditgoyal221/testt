<?php
session_start();
include ("connection.php");
$user=$_SESSION['uname'];
$room=$_SESSION['code'];
$ip =$_SESSION['ip'];
$q1 = "UPDATE users SET call_id='not' WHERE username ='$user' and room_id='$room'";

    $run_2=mysqli_query($conn,$q1);
?>