<?php
session_start();
include ("connection.php");
$user=$_SESSION['uname'];
$room=$_SESSION['code'];
$ip =$_SESSION['ip'];
$caller=$_POST['username'];
$q1 = "UPDATE users SET call_id='start' WHERE username ='$caller' and room_id='$room'";

    $run_2=mysqli_query($conn,$q1);
?>