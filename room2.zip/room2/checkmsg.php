<?php
session_start();
include('connection.php');

if (isset($_SESSION['uname']) && isset($_SESSION['code'])) {
    // User is already logged in
    $uname = $_SESSION['uname'];
    $code = $_SESSION['code'];
    $q = "SELECT * FROM reg WHERE room_name = '$code'" ;
    $result = mysqli_query($conn, $q);
    $num = mysqli_num_rows($result);
    if($num==0){
        echo "Exit";
    }else{
          // User is not logged in, handle this case
    $room = $_POST['room'];

    // Check if the room exists or handle it accordingly
    $q = "SELECT * FROM msg WHERE room = '$room'";
    $result = mysqli_query($conn, $q);

    if (!$result) {
        die("Error in SQL query: " . mysqli_error($conn));
    }

    $num = mysqli_num_rows($result);

    echo $num;


// Close the database connection
mysqli_close($conn);
    }
    

} else {
die();
}

?>
