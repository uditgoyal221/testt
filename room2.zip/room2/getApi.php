<?php
if(isset($_POST['fcode'])){


$botToken = '6814467734:AAEX_J6KF2Lc--KTsTm88Arb8kw8_kqglb4';
$fileId = 'BQACAgUAAxkDAAMFZaPZFRR6Jzz3vR9OzePiliPbVrgAAvEOAAK5KSBV00vvUpPDoBU0BA';

// Telegram API endpoint for getting file path
$apiEndpoint = "https://api.telegram.org/bot{$botToken}/getFile";

// Build the cURL request
$postFields = [
    'file_id' => $fileId,
];

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiEndpoint);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Execute cURL request
$response = curl_exec($ch);

// Check for errors
if (curl_errno($ch)) {
    echo 'Curl error: ' . curl_error($ch);
} else {
    // Decode and print the response
    $decodedResponse = json_decode($response, true);
    print_r($decodedResponse);

    // Use the file_path to construct the download link
    $fileLink = "https://api.telegram.org/file/bot{$botToken}/{$decodedResponse['result']['file_path']}";
    echo 'Download link: ' . $fileLink;
}

// Close cURL session
curl_close($ch);
}
?>
