<?php
session_start();
include('connection.php');
$c=0;
if (isset($_SESSION['uname']) && isset($_SESSION['code'])) {
    $uname = $_SESSION['uname'];
    $code = $_SESSION['code'];
    $sql="select * from users where room_id='$code'";
    $result = mysqli_query($conn, $sql);
    $num = mysqli_num_rows($result);
    $sql1="select * from users where room_id='$code' and username='$uname' and removed='removed'";
    $result2 = mysqli_query($conn, $sql1);
    $sq="select * from users where room_id='$code' and username='$uname'";
    $re = mysqli_query($conn, $sq);
    $num1 = mysqli_num_rows($result2);
    $r=mysqli_fetch_assoc($re);
    if($num1>0){
        echo "Exit";
        exit;
    } else if(isset($r['call_id']) && $r['call_id']!=NULL && $r['call_id']!="not" && $r['call_id']!="start"){
        echo $r['call_id'];
    } else if(isset($r['call_id']) && $r['call_id']!=NULL && $r['call_id']=="start"){
        echo "recived";
    } else {
        $time=time();
        while($row=mysqli_fetch_assoc($result)){ 
            if($row['last_login']>$time){
                $c++;
            }
        }
        echo $c;
    }
    // Close the database connection
    mysqli_close($conn);
} else {
    die();
}
?>
